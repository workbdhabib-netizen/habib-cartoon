# Android ফোন থেকে MP4 Render (সহজ পদ্ধতি)

Remotion-এর ভিডিও রেন্ডারিং Android/Termux-এ সরাসরি নির্ভরযোগ্যভাবে চলে না। ফোন থেকে করার সবচেয়ে বাস্তব উপায় হলো browser-based Linux workspace (যেমন GitHub Codespaces) ব্যবহার করা।

## পদ্ধতি: GitHub Codespaces (ফোনের Chrome দিয়ে)
1. ZIP ফাইলটি ফোনে Extract করো।
2. GitHub-এ নতুন repository বানিয়ে প্রজেক্ট ফাইলগুলো upload করো (ZIP হিসেবে নয়—Extract করা ফাইলগুলো)।
3. Repository-তে **Code → Codespaces → Create codespace** নির্বাচন করো।
4. Codespace Terminal খুলে এই কমান্ডগুলো চালাও:

```bash
npm install
npx remotion render MainVideo out/video.mp4
```

5. Render শেষ হলে `out/video.mp4` ফাইলটি Codespace থেকে Download করো।

## সতর্কতা
- Codespaces অ্যাকাউন্ট/ব্যবহার-সীমা ও availability বদলাতে পারে।
- Render করতে সময়, RAM এবং CPU লাগবে; বড় ভিডিওতে খরচ/usage limit হতে পারে।
- Remotion rendering-এর জন্য browser dependencies প্রয়োজন; Codespaces-এ সমস্যা হলে Linux browser dependencies install বা project configuration লাগতে পারে।
- Android-এ Termux দিয়ে সরাসরি রেন্ডার করার নিশ্চয়তা নেই। এই প্রজেক্টের জন্য phone-only workflow tested নয়।
