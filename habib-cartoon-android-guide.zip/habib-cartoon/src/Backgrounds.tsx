import React from 'react';
import {INK, SW} from './theme';
import {Sign} from './Props';

// ---------- বারান্দা (ঘর) ----------
// পেছনের স্তর: জানালার বাইরের দৃশ্য (আকাশ, গাছ, মাঠ)
export const VerandaBack: React.FC<{dusk?: number}> = ({dusk = 0}) => (
  <g>
    <defs>
      <linearGradient id="skyV" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={dusk > 0 ? '#F9C98A' : '#9ED8FF'} />
        <stop offset="1" stopColor={dusk > 0 ? '#FFE9C8' : '#E4F6FF'} />
      </linearGradient>
    </defs>
    <rect x={0} y={0} width={1920} height={1080} fill="url(#skyV)" />
    <ellipse cx={1500} cy={250} rx={90} ry={34} fill="#fff" opacity={0.9} />
    <ellipse cx={1580} cy={236} rx={60} ry={28} fill="#fff" opacity={0.9} />
    <rect x={1300} y={520} width={600} height={160} fill="#8FD07A" />
    <circle cx={1450} cy={500} r={64} fill="#4FA85A" stroke={INK} strokeWidth={SW} />
    <rect x={1440} y={540} width={20} height={70} fill="#7A4A2A" />
    <circle cx={1700} cy={520} r={52} fill="#5CB867" stroke={INK} strokeWidth={SW} />
  </g>
);

// সামনের স্তর: দেয়াল (জানালার ফোকর সহ), মেঝে, দরজা, ঘড়ি
export const VerandaFront: React.FC<{tint?: string}> = ({tint}) => (
  <g>
    <path
      d="M0 0 H1920 V768 H0 Z M1360 170 H1800 V640 H1360 Z"
      fillRule="evenodd"
      fill="#FBE9C6"
    />
    <rect x={0} y={560} width={1920} height={208} fill="#F2D49C" />
    <rect x={0} y={556} width={1920} height={12} fill="#E3BC76" />
    {/* মেঝে */}
    <rect x={0} y={768} width={1920} height={312} fill="#D9B88C" />
    <rect x={0} y={768} width={1920} height={16} fill="#B99466" />
    {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
      <path key={i} d={`M${i * 240} 784 L${960 + (i * 240 - 960) * 1.7} 1080`} stroke="#C4A072" strokeWidth={3} />
    ))}
    {[860, 960, 1060].map((yy) => (
      <path key={yy} d={`M0 ${yy} H1920`} stroke="#C4A072" strokeWidth={3} />
    ))}
    {/* দরজা (খোলা, বাইরে উঠোন) */}
    <rect x={70} y={190} width={330} height={580} rx={14} fill="#7A4A2A" stroke={INK} strokeWidth={SW + 1} />
    <rect x={92} y={214} width={286} height={556} fill="#CFEBB0" />
    <rect x={92} y={214} width={286} height={300} fill="#BFE7FF" />
    <circle cx={290} cy={560} r={54} fill="#6CBF6B" stroke={INK} strokeWidth={SW} />
    <path d="M92 770 H378" stroke="#9BC57A" strokeWidth={8} />
    {/* ঘড়ি */}
    <circle cx={880} cy={210} r={64} fill="#fff" stroke={INK} strokeWidth={SW + 1} />
    <path d="M880 210 V166 M880 210 L910 226" stroke={INK} strokeWidth={5} strokeLinecap="round" fill="none" />
    <circle cx={880} cy={210} r={5} fill={INK} />
    {/* জানালা ফ্রেম ও গ্রিল */}
    <rect x={1360} y={170} width={440} height={470} fill="none" stroke="#7A4A2A" strokeWidth={18} />
    {[1430, 1506, 1582, 1658, 1734].map((gx) => (
      <path key={gx} d={`M${gx} 172 V638`} stroke="#7A4A2A" strokeWidth={9} />
    ))}
    <rect x={1330} y={636} width={500} height={34} rx={8} fill="#E8D3A8" stroke={INK} strokeWidth={SW} />
    {tint && <rect x={0} y={0} width={1920} height={1080} fill={tint} />}
  </g>
);

// ---------- নার্সারি + রাস্তা ----------
const Pots: React.FC<{y: number; x0: number; n: number; seed: number}> = ({y, x0, n, seed}) => (
  <g>
    {Array.from({length: n}).map((_, i) => {
      const px = x0 + i * 112;
      const hh = 34 + ((i * 7 + seed) % 4) * 10;
      const col = ['#C8683A', '#D98A4B', '#B85A30'][(i + seed) % 3];
      return (
        <g key={i} transform={`translate(${px},${y})`}>
          <path d="M-30 -52 H30 L22 0 H-22Z" fill={col} stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
          <circle cx={0} cy={-52 - hh * 0.6} r={hh * 0.7} fill={['#5CB867', '#3FA663', '#7BC95A'][(i + seed) % 3]} stroke={INK} strokeWidth={SW} />
          <circle cx={-16} cy={-52 - hh * 0.3} r={hh * 0.4} fill="#4FB45E" stroke={INK} strokeWidth={SW} />
        </g>
      );
    })}
  </g>
);

export const NurseryBack: React.FC = () => (
  <g>
    <defs>
      <linearGradient id="skyN" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#9ED8FF" />
        <stop offset="1" stopColor="#E8F7FF" />
      </linearGradient>
    </defs>
    <rect x={0} y={0} width={1920} height={780} fill="url(#skyN)" />
    <circle cx={260} cy={170} r={70} fill="#FFE27A" stroke={INK} strokeWidth={SW} />
    <ellipse cx={560} cy={140} rx={90} ry={30} fill="#fff" opacity={0.95} />
    {/* রাস্তার পাশের গাছ */}
    <rect x={360} y={380} width={40} height={400} fill="#8A5A2B" stroke={INK} strokeWidth={SW} />
    <circle cx={380} cy={330} r={120} fill="#4FA85A" stroke={INK} strokeWidth={SW} />
    <circle cx={300} cy={400} r={80} fill="#5CB867" stroke={INK} strokeWidth={SW} />
    {/* দোকানের ভেতরের দেয়াল ও তাক */}
    <rect x={760} y={250} width={1160} height={530} fill="#F6EEDA" stroke={INK} strokeWidth={SW} />
    {[430, 570, 710].map((sy, i) => (
      <g key={sy}>
        <rect x={790} y={sy} width={1100} height={14} fill="#B9803F" stroke={INK} strokeWidth={SW} />
        <Pots y={sy} x0={850 + (i % 2) * 40} n={9} seed={i * 2} />
      </g>
    ))}
    {/* সামিয়ানা */}
    {Array.from({length: 12}).map((_, i) => (
      <path
        key={i}
        d={`M${740 + i * 100} 150 H${840 + i * 100} V250 Q${790 + i * 100} 285 ${740 + i * 100} 250 Z`}
        fill={i % 2 === 0 ? '#3FA663' : '#FFFFFF'}
        stroke={INK}
        strokeWidth={SW}
        strokeLinejoin="round"
      />
    ))}
    <Sign x={1320} y={26} text="চারা গাছের দোকান" />
    {/* ফুটপাত ও রাস্তা */}
    <rect x={0} y={780} width={1920} height={40} fill="#E6DFD2" stroke={INK} strokeWidth={SW} />
    <rect x={0} y={820} width={1920} height={260} fill="#BDB6AA" />
    <path d="M0 940 H1920" stroke="#D9D3C8" strokeWidth={8} strokeDasharray="60 50" />
  </g>
);
