import React from 'react';
import {useCurrentFrame} from 'remotion';
import {INK, SW} from './theme';

export type Kind = 'habib' | 'sajid' | 'dadu' | 'ma' | 'rahim';
export type Mood =
  | 'neutral' | 'happy' | 'sad' | 'worried' | 'surprised' | 'angry' | 'thinking'
  | 'smug' | 'excited' | 'nervous' | 'cry' | 'relieved' | 'focused';
export type Hold = 'none' | 'mug' | 'bat' | 'cane' | 'spoon' | 'phone' | 'money';

export interface CharProps {
  kind: Kind;
  x: number; // পায়ের মাঝখান
  y: number; // মাটির লেভেল
  scale?: number;
  flip?: boolean; // true হলে আয়না-উল্টানো (প্রপ ওপাশে)
  mood?: Mood;
  talking?: boolean;
  walk?: 0 | 1 | 2; // 0 স্থির, 1 হাঁটা, 2 দৌড়
  armL?: number; // "বাইরের দিকে" ডিগ্রি: 0 ঝুলে, 90 পাশে সোজা, 180 উপরে, ঋণাত্মক = শরীরের দিকে
  armR?: number;
  holdL?: Hold;
  holdR?: Hold;
  lean?: number;
  look?: number; // -1..1 চোখের দিক
  tremble?: number;
  sit?: boolean;
  hop?: number;
  seed?: number;
  opacity?: number;
}

const SP: Record<Kind, {skin: string; hair: string; k: number; head: number}> = {
  habib: {skin: '#D6A07A', hair: '#1F1F1F', k: 0.84, head: 1.12},
  sajid: {skin: '#CF9770', hair: '#2A2018', k: 0.84, head: 1.12},
  dadu: {skin: '#C98E66', hair: '#F4F4F4', k: 1.0, head: 1.0},
  ma: {skin: '#D9A47E', hair: '#1F1F1F', k: 1.0, head: 1.0},
  rahim: {skin: '#C38A62', hair: '#8C8C8C', k: 1.04, head: 1.0},
};

const MOODS: Record<Mood, {b: number; raise: number; mouth: string}> = {
  neutral: {b: 0, raise: 0, mouth: 'flat'},
  happy: {b: -6, raise: -4, mouth: 'smile'},
  sad: {b: -20, raise: 2, mouth: 'frown'},
  worried: {b: -16, raise: -3, mouth: 'wobble'},
  surprised: {b: -4, raise: -16, mouth: 'o'},
  angry: {b: 18, raise: 4, mouth: 'frown'},
  thinking: {b: 8, raise: -4, mouth: 'smirk'},
  smug: {b: 10, raise: -2, mouth: 'smirk'},
  excited: {b: -6, raise: -12, mouth: 'big'},
  nervous: {b: -14, raise: -4, mouth: 'wobble'},
  cry: {b: -22, raise: 2, mouth: 'frown'},
  relieved: {b: -8, raise: -2, mouth: 'smile'},
  focused: {b: 6, raise: 2, mouth: 'flat'},
};

const cap = (w: number, len: number, fill: string, key?: string) => (
  <rect key={key} x={-w / 2} y={0} width={w} height={len} rx={w / 2} fill={fill} stroke={INK} strokeWidth={SW} />
);

const renderHold = (h: Hold): React.ReactNode => {
  switch (h) {
    case 'mug':
      return (
        <g>
          <path d="M16 -14 h10 a11 11 0 0 1 0 28 h-9" fill="none" stroke={INK} strokeWidth={SW + 1} />
          <rect x={-19} y={-26} width={38} height={46} rx={7} fill="#4A86E8" stroke={INK} strokeWidth={SW} />
          <rect x={-19} y={-26} width={38} height={9} rx={4} fill="#fff" stroke={INK} strokeWidth={SW} />
        </g>
      );
    case 'bat':
      return (
        <g>
          <rect x={-7} y={-150} width={14} height={160} rx={6} fill="#B9803F" stroke={INK} strokeWidth={SW} />
          <path d="M-19 -155 L19 -155 L15 -74 L-15 -74 Z" fill="#D9A25A" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
        </g>
      );
    case 'cane':
      return (
        <g>
          <path d="M0 -8 V158" stroke={INK} strokeWidth={13} strokeLinecap="round" />
          <path d="M0 -8 V158" stroke="#8A5A2B" strokeWidth={8} strokeLinecap="round" />
          <path d="M0 -8 Q0 -34 -24 -30" stroke={INK} strokeWidth={13} strokeLinecap="round" fill="none" />
          <path d="M0 -8 Q0 -34 -24 -30" stroke="#8A5A2B" strokeWidth={8} strokeLinecap="round" fill="none" />
        </g>
      );
    case 'spoon':
      return (
        <g>
          <rect x={-5} y={0} width={10} height={62} rx={5} fill="#C9D0D8" stroke={INK} strokeWidth={SW} />
          <ellipse cx={0} cy={80} rx={16} ry={22} fill="#DDE3EA" stroke={INK} strokeWidth={SW} />
        </g>
      );
    case 'phone':
      return (
        <g>
          <rect x={-24} y={-62} width={48} height={84} rx={9} fill="#2B2F36" stroke={INK} strokeWidth={SW} />
          <rect x={-19} y={-53} width={38} height={62} rx={3} fill="#D9F2D0" />
          <path d="M0 4 V-18" stroke="#3E8E41" strokeWidth={4} strokeLinecap="round" />
          <path d="M0 -16 Q-12 -18 -14 -30 Q-2 -30 0 -16Z M0 -12 Q12 -16 14 -26 Q2 -26 0 -12Z" fill="#6BBF59" />
        </g>
      );
    case 'money':
      return (
        <g transform="rotate(-12)">
          <rect x={-30} y={-16} width={60} height={34} rx={5} fill="#7BC47F" stroke={INK} strokeWidth={SW} />
          <circle cx={0} cy={1} r={10} fill="#CFEFC9" stroke={INK} strokeWidth={2} />
        </g>
      );
    default:
      return null;
  }
};

export const Character: React.FC<CharProps> = ({
  kind,
  x,
  y,
  scale = 1.7,
  flip = false,
  mood = 'neutral',
  talking = false,
  walk = 0,
  armL,
  armR,
  holdL = 'none',
  holdR = 'none',
  lean = 0,
  look = 0,
  tremble = 0,
  sit = false,
  hop = 0,
  seed = 0,
  opacity = 1,
}) => {
  const f = useCurrentFrame();
  const sp = SP[kind];
  const isKid = kind === 'habib' || kind === 'sajid';

  // জীবন্ত ভাসা + পলক
  const idle = Math.sin((f + seed * 17) / 13) * 4;
  const blink = (f + seed * 41) % 105 < 4 ? 0.12 : 1;
  const wsp = walk === 2 ? 0.62 : 0.36;
  const ph = walk ? Math.sin(f * wsp + seed) : 0;
  const bob = walk ? Math.abs(Math.cos(f * wsp + seed)) * (walk === 2 ? 12 : 7) : 0;
  const legA = walk === 2 ? 38 : 24;
  const hopY = hop ? Math.abs(Math.sin(f / 5 + seed)) * hop : 0;
  const trX = tremble ? Math.sin(f * 2.3 + seed) * tremble : 0;
  const trY = tremble ? Math.cos(f * 3.1 + seed) * tremble * 0.6 : 0;

  const shift = sit ? 62 : 0;
  const bodyY = idle - bob - hopY + shift;
  const hipY = -128;

  // বাহুর কোণ (আউট-ডিগ্রি)
  const aL = armL !== undefined ? armL : walk ? -ph * (walk === 2 ? 55 : 28) + 6 : 6;
  const aR = armR !== undefined ? armR : walk ? ph * (walk === 2 ? 55 : 28) + 6 : 6;

  const m = MOODS[mood];
  const tseq = [1, 2, 1, 0, 2, 1, 2, 0];
  const shape = talking ? tseq[(Math.floor(f / 3) + seed) % 8] : -1;
  const mouthY = kind === 'dadu' ? -274 : -292;

  const skin = sp.skin;
  const uid = `${kind}${seed}`;

  const mouth = (): React.ReactNode => {
    if (shape === 0) return <path d="M-18 2 Q0 10 18 2" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />;
    if (shape === 1) return <ellipse cx={0} cy={4} rx={14} ry={9} fill="#7A1F2B" stroke={INK} strokeWidth={SW} />;
    if (shape === 2)
      return (
        <g>
          <ellipse cx={0} cy={8} rx={19} ry={17} fill="#7A1F2B" stroke={INK} strokeWidth={SW} />
          <ellipse cx={0} cy={16} rx={10} ry={6} fill="#E8737F" />
        </g>
      );
    switch (m.mouth) {
      case 'smile':
        return <path d="M-24 0 Q0 24 24 0" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />;
      case 'big':
        return (
          <g>
            <path d="M-28 -3 Q0 40 28 -3 Z" fill="#7A1F2B" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
            <path d="M-14 14 Q0 8 14 14 Q0 28 -14 14Z" fill="#E8737F" />
          </g>
        );
      case 'frown':
        return <path d="M-20 10 Q0 -8 20 10" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />;
      case 'o':
        return <ellipse cx={0} cy={6} rx={11} ry={15} fill="#7A1F2B" stroke={INK} strokeWidth={SW} />;
      case 'wobble':
        return <path d="M-24 6 Q-12 -6 0 6 Q12 18 24 6" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />;
      case 'smirk':
        return <path d="M-20 6 Q8 14 24 -6" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />;
      default:
        return <path d="M-16 4 L16 4" stroke={INK} strokeWidth={5} strokeLinecap="round" />;
    }
  };

  const arm = (side: -1 | 1, out: number, hold: Hold) => {
    const sleeveLen = kind === 'habib' || kind === 'ma' ? 48 : kind === 'sajid' ? 46 : 84;
    const sleeveColor =
      kind === 'habib' ? '#FFD23F' : kind === 'sajid' ? '#2E9E5B' : kind === 'dadu' ? '#FAFAFA' : kind === 'ma' ? '#E9879F' : '#8E2A3A';
    return (
      <g transform={`translate(${side * 66},-252) rotate(${-side * out})`}>
        {cap(28, 100, skin)}
        {cap(34, sleeveLen, sleeveColor)}
        {kind === 'sajid' && <rect x={-17} y={sleeveLen - 12} width={34} height={8} fill="#fff" />}
        <circle cx={0} cy={102} r={17} fill={skin} stroke={INK} strokeWidth={SW} />
        <g transform="translate(0,102)">{renderHold(hold)}</g>
      </g>
    );
  };

  const leg = (side: -1 | 1) => {
    const a = side * ph * legA;
    const shorts = kind === 'habib' ? '#3E6FD1' : '#C9B27C';
    return (
      <g key={side} transform={`translate(${side * 28},${hipY + shift}) rotate(${a})`}>
        {sit ? cap(32, 56, skin) : cap(32, 118, skin)}
        {isKid && cap(40, sit ? 56 : 62, shorts)}
        <ellipse cx={side * 6} cy={sit ? 62 : 124} rx={28} ry={13} fill={kind === 'habib' ? '#FFFFFF' : '#F4F4F4'} stroke={INK} strokeWidth={SW} />
      </g>
    );
  };

  const feet = () =>
    [-1, 1].map((s) => (
      <ellipse
        key={s}
        cx={s * 30 + (walk ? s * ph * 12 : 0)}
        cy={-8 - (walk ? Math.max(0, s * ph) * 9 : 0)}
        rx={28}
        ry={13}
        fill={kind === 'ma' ? '#E9879F' : skin}
        stroke={INK}
        strokeWidth={SW}
      />
    ));

  const sx = scale * sp.k;
  const flipSign = flip ? -1 : 1;

  return (
    <g
      opacity={opacity}
      transform={`translate(${x + trX},${y + trY}) scale(${sx * flipSign},${sx}) rotate(${lean})`}
    >
      <defs>
        <pattern id={`chkD${uid}`} width="38" height="38" patternUnits="userSpaceOnUse">
          <rect width="38" height="38" fill="#F2EFE4" />
          <rect width="19" height="38" fill="#3B6FA8" opacity="0.6" />
          <rect width="38" height="19" fill="#3B6FA8" opacity="0.6" />
        </pattern>
        <pattern id={`chkR${uid}`} width="30" height="30" patternUnits="userSpaceOnUse">
          <rect width="30" height="30" fill="#A9AEB4" />
          <rect width="3" height="30" fill="#8A9097" />
          <rect width="30" height="3" fill="#8A9097" />
        </pattern>
        <pattern id={`chkG${uid}`} width="22" height="22" patternUnits="userSpaceOnUse">
          <rect width="22" height="22" fill="#fff" />
          <rect width="11" height="22" fill="#D63B3B" opacity="0.85" />
          <rect width="22" height="11" fill="#D63B3B" opacity="0.85" />
        </pattern>
        <clipPath id={`clipT${uid}`}>
          <rect x={-60} y={-274} width={120} height={152} rx={38} />
        </clipPath>
      </defs>

      {/* মাটির ছায়া */}
      <ellipse cx={0} cy={4} rx={86} ry={14} fill="rgba(0,0,0,0.14)" />

      {/* পা / নিচের পোশাক */}
      {isKid ? (
        <g transform={`translate(0,${idle * 0.2 - bob + 0})`}>
          {leg(-1)}
          {leg(1)}
        </g>
      ) : (
        <g transform={`translate(0,${-bob})`}>
          {feet()}
          {kind === 'dadu' && (
            <path
              d={`M-70 ${hipY + shift} L70 ${hipY + shift} L84 -10 Q0 8 -84 -10 Z`}
              fill={`url(#chkD${uid})`}
              stroke={INK}
              strokeWidth={SW}
              strokeLinejoin="round"
            />
          )}
          {kind === 'rahim' && (
            <path
              d={`M-76 ${hipY + shift} L76 ${hipY + shift} L90 -10 Q0 8 -90 -10 Z`}
              fill={`url(#chkR${uid})`}
              stroke={INK}
              strokeWidth={SW}
              strokeLinejoin="round"
            />
          )}
          {kind === 'ma' && (
            <g>
              <path
                d={`M-68 ${hipY + shift} L68 ${hipY + shift} L86 -10 Q0 8 -86 -10 Z`}
                fill="#F4A9C3"
                stroke={INK}
                strokeWidth={SW}
                strokeLinejoin="round"
              />
              <path d="M-84 -36 L84 -36 L86 -10 Q0 8 -86 -10 Z" fill="#D9578B" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
            </g>
          )}
        </g>
      )}

      <g transform={`translate(0,${bodyY})`}>
        {/* ধড় */}
        {kind === 'habib' && (
          <rect x={-60} y={-274} width={120} height={152} rx={38} fill="#FFD23F" stroke={INK} strokeWidth={SW} />
        )}
        {kind === 'sajid' && (
          <g>
            <rect x={-60} y={-274} width={120} height={152} rx={38} fill="#fff" />
            <g clipPath={`url(#clipT${uid})`}>
              {[-60, -20, 20].map((sx0) => (
                <rect key={sx0} x={sx0} y={-274} width={20} height={152} fill="#2E9E5B" />
              ))}
            </g>
            <rect x={-60} y={-274} width={120} height={152} rx={38} fill="none" stroke={INK} strokeWidth={SW} />
          </g>
        )}
        {kind === 'dadu' && (
          <g>
            <rect x={-66} y={-274} width={132} height={216} rx={36} fill="#FAFAFA" stroke={INK} strokeWidth={SW} />
            <path d="M0 -262 V-150" stroke={INK} strokeWidth={2.5} />
            {[-236, -208, -180].map((by) => (
              <circle key={by} cx={0} cy={by} r={4} fill="#9AA3AD" stroke={INK} strokeWidth={1.5} />
            ))}
          </g>
        )}
        {kind === 'ma' && (
          <g>
            <rect x={-60} y={-274} width={120} height={160} rx={36} fill="#F4A9C3" stroke={INK} strokeWidth={SW} />
            <path d="M-56 -262 L-6 -274 L66 -150 L58 -112 Z" fill="#D9578B" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
            <path d="M52 -168 L74 -150 L72 -52 L48 -60 Z" fill="#D9578B" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
          </g>
        )}
        {kind === 'rahim' && (
          <rect x={-74} y={-274} width={148} height={184} rx={34} fill="#8E2A3A" stroke={INK} strokeWidth={SW} />
        )}
        {kind === 'rahim' && (
          <g>
            <path d="M-52 -278 Q0 -246 52 -278 L60 -250 Q0 -218 -60 -250 Z" fill={`url(#chkG${uid})`} stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
            <path d="M24 -250 L62 -246 L70 -150 L32 -144 Z" fill={`url(#chkG${uid})`} stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
          </g>
        )}
        {/* গলা */}
        <rect x={-18} y={-290} width={36} height={30} fill={skin} />

        {/* হাত */}
        {arm(-1, flip ? aR : aL, flip ? holdR : holdL)}
        {arm(1, flip ? aL : aR, flip ? holdL : holdR)}

        {/* মাথা */}
        <g transform={`translate(0,-285) scale(${sp.head}) translate(0,285)`}>
          {/* চুল পেছনে (সাজিদের এলোমেলো) */}
          {kind === 'sajid' && (
            <path
              d="M-52 -392 L-64 -432 L-32 -406 L-22 -444 L0 -408 L24 -446 L36 -406 L66 -434 L56 -390 Z"
              fill={sp.hair}
              stroke={INK}
              strokeWidth={SW}
              strokeLinejoin="round"
            />
          )}
          {kind === 'ma' && <circle cx={0} cy={-426} r={36} fill={sp.hair} stroke={INK} strokeWidth={SW} />}
          {/* কান */}
          <ellipse cx={-76} cy={-336} rx={11} ry={17} fill={skin} stroke={INK} strokeWidth={SW} />
          <ellipse cx={76} cy={-336} rx={11} ry={17} fill={skin} stroke={INK} strokeWidth={SW} />
          {/* মুখমণ্ডল */}
          <ellipse cx={0} cy={-338} rx={76} ry={70} fill={skin} stroke={INK} strokeWidth={SW} />

          {/* চুল / টুপি */}
          {(kind === 'habib' || kind === 'sajid' || kind === 'ma') && (
            <path
              d="M-76 -330 Q-82 -414 0 -416 Q82 -414 76 -330 Q60 -368 0 -370 Q-60 -368 -76 -330 Z"
              fill={sp.hair}
              stroke={INK}
              strokeWidth={SW}
              strokeLinejoin="round"
            />
          )}
          {kind === 'dadu' && (
            <g>
              <ellipse cx={-70} cy={-346} rx={14} ry={24} fill="#F4F4F4" stroke={INK} strokeWidth={SW} />
              <ellipse cx={70} cy={-346} rx={14} ry={24} fill="#F4F4F4" stroke={INK} strokeWidth={SW} />
            </g>
          )}
          {kind === 'rahim' && (
            <g>
              <path d="M-72 -366 Q-76 -436 0 -440 Q76 -436 72 -366 Q0 -390 -72 -366 Z" fill="#FFFFFF" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
              <path d="M-72 -366 Q0 -390 72 -366" fill="none" stroke="#C9CDD2" strokeWidth={4} />
            </g>
          )}
          {kind === 'ma' && <circle cx={0} cy={-382} r={5.5} fill="#111" />}

          {/* গাল */}
          <circle cx={-48} cy={-314} r={13} fill="#F08A7A" opacity={0.35} />
          <circle cx={48} cy={-314} r={13} fill="#F08A7A" opacity={0.35} />

          {/* চোখ */}
          {[-1, 1].map((s) => (
            <g key={s} transform={`translate(${s * 28},-338)`}>
              <ellipse cx={0} cy={0} rx={17} ry={19 * blink} fill="#fff" stroke={INK} strokeWidth={SW} />
              <g transform={`scale(1,${blink})`}>
                <circle cx={look * 6} cy={1} r={9.5} fill="#1B1B1B" />
                <circle cx={look * 6 + 3} cy={-3} r={3} fill="#fff" />
              </g>
            </g>
          ))}

          {/* ভ্রু */}
          {[-1, 1].map((s) => (
            <line
              key={s}
              x1={-17}
              y1={0}
              x2={17}
              y2={0}
              stroke={kind === 'dadu' ? '#8F8F8F' : INK}
              strokeWidth={kind === 'dadu' ? 9 : 6.5}
              strokeLinecap="round"
              transform={`translate(${s * 28},${-372 + m.raise}) rotate(${s === -1 ? m.b : -m.b})`}
            />
          ))}

          {/* চশমা (দাদু) */}
          {kind === 'dadu' && (
            <g fill="rgba(255,255,255,0.25)" stroke={INK} strokeWidth={5}>
              <circle cx={-28} cy={-338} r={27} />
              <circle cx={28} cy={-338} r={27} />
              <path d="M-2 -340 H2 M-55 -342 L-72 -346 M55 -342 L72 -346" fill="none" />
            </g>
          )}

          {/* নাক */}
          <path d="M-6 -318 Q0 -310 6 -318" fill="none" stroke="#8A5A3A" strokeWidth={3.5} strokeLinecap="round" />

          {/* দাড়ি / গোঁফ */}
          {kind === 'dadu' && (
            <path
              d="M-72 -330 Q-82 -226 0 -214 Q82 -226 72 -330 Q54 -296 24 -298 Q0 -306 -24 -298 Q-54 -296 -72 -330 Z"
              fill="#FFFFFF"
              stroke={INK}
              strokeWidth={SW}
              strokeLinejoin="round"
            />
          )}
          {kind === 'dadu' && (
            <path d="M-34 -300 Q-18 -322 0 -306 Q18 -322 34 -300 Q18 -290 0 -298 Q-18 -290 -34 -300Z" fill="#FFFFFF" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
          )}
          {kind === 'rahim' && (
            <path d="M-28 -308 Q-14 -324 0 -310 Q14 -324 28 -308 Q14 -298 0 -304 Q-14 -298 -28 -308Z" fill="#8C8C8C" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
          )}

          {/* মুখ */}
          <g transform={`translate(0,${mouthY})`}>{mouth()}</g>

          {/* কান্নার ফোঁটা */}
          {(mood === 'cry' || mood === 'sad') && (
            <g>
              {[-1, 1].map((s) => {
                const p = ((f + (s === 1 ? 14 : 0)) % 40) / 40;
                return (
                  <path
                    key={s}
                    d="M0 0 C0 0 -8 12 -8 18 A8 8 0 0 0 8 18 C8 12 0 0 0 0Z"
                    fill="#6EC3F5"
                    stroke={INK}
                    strokeWidth={2}
                    opacity={mood === 'cry' ? 1 - p * 0.7 : 0.8 * (1 - p)}
                    transform={`translate(${s * 32},${-322 + p * 40})`}
                  />
                );
              })}
            </g>
          )}
        </g>
      </g>
    </g>
  );
};
