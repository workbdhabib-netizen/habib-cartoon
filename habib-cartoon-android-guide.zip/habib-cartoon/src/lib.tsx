import React, {createContext, useContext} from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';

// প্রতিটি সিন তার শুরুর সময় (সেকেন্ড) এখানে দেয়, যাতে সবকিছু absolute সময়ে লেখা যায়।
export const SceneCtx = createContext(0);

export const useT = (): number => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const off = useContext(SceneCtx);
  return f / fps + off;
};

export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
const smooth = (x: number) => x * x * (3 - 2 * x);

// কিফ্রেম ইন্টারপোলেশন: [[সময়, মান], ...]
export function kf(t: number, pts: Array<[number, number]>, ease = true): number {
  if (t <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) {
    if (t <= pts[i][0]) {
      const [t0, v0] = pts[i - 1];
      const [t1, v1] = pts[i];
      let u = (t - t0) / (t1 - t0);
      if (ease) u = smooth(u);
      return v0 + (v1 - v0) * u;
    }
  }
  return pts[pts.length - 1][1];
}

// t0 সময় থেকে 0 -> ~1 স্প্রিং পপ
export function usePop(t0: number, damping = 12, stiffness = 150): number {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const off = useContext(SceneCtx);
  const local = f - (t0 - off) * fps;
  if (local < 0) return 0;
  return spring({frame: local, fps, config: {damping, stiffness, mass: 0.6}});
}

// t0..t1-এর মধ্যে 0->1->0 ফেড
export function fadeWin(t: number, t0: number, t1: number, inD = 0.25, outD = 0.25): number {
  return clamp((t - t0) / inD, 0, 1) * clamp((t1 - t) / outD, 0, 1);
}

export const Show: React.FC<{t0: number; t1: number; children: React.ReactNode}> = ({t0, t1, children}) => {
  const t = useT();
  return t >= t0 && t <= t1 ? <>{children}</> : null;
};
