import React from 'react';
import {AbsoluteFill} from 'remotion';
import {useT, kf, usePop, clamp} from '../lib';
import {Sapling, MugProp} from '../Props';
import {Icon} from '../Icons';
import {Card, SceneFrame, Stage} from '../Overlays';
import {fontFamily} from '../theme';

const rich = (text: string, color: string) =>
  text.split(/(\{[^}]+\})/g).map((p, i) =>
    p.startsWith('{') ? (
      <span key={i} style={{color}}>
        {p.slice(1, -1)}
      </span>
    ) : (
      <span key={i}>{p}</span>
    ),
  );

// দৃশ্য ৮ — শিক্ষা: ক্লিন মোশন গ্রাফিক্স, কোটেশন কার্ড ও প্রশ্ন কার্ড
export const S8: React.FC<{dur: number}> = ({dur}) => {
  const t = useT();
  const chip = usePop(152.4);
  const fresh = kf(t, [[145.7, 0.6], [147, 1]]);
  void clamp;

  const q = (text: string) => (
    <div style={{fontFamily, fontWeight: 700, fontSize: 70, lineHeight: 1.3, textAlign: 'center', whiteSpace: 'pre-line'}}>
      {rich(text, '#E0453A')}
    </div>
  );

  return (
    <SceneFrame dur={dur} bg="#E3F2C9">
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #F6FFE4 0%, #E3F2C9 70%, #C9E3A4 100%)'}} />
      <Stage>
        <ellipse cx={500} cy={965} rx={420} ry={40} fill="rgba(80,130,50,0.2)" />
        <Sapling x={470} y={960} scale={2.3} droop={0} fresh={fresh} sway={t * 30} />
        <MugProp x={790} y={955} scale={1.8} rot={-4} />
      </Stage>

      <Icon name="leaf" x={160} y={260} size={90} t0={146.0} t1={154.2} float={14} rot={-20} />
      <Icon name="sparkle" x={760} y={470} size={90} t0={147.0} t1={154.2} spin={40} />
      <Icon name="drop" x={900} y={820} size={80} t0={148.8} t1={154.2} float={12} />

      <Card t0={145.85} t1={148.5} x={900} y={290} w={940} rot={-1.5} pin={false}>
        {q('চারাগাছ কখনো বলে না\nতার {পানি দরকার}।')}
      </Card>
      <Card t0={148.65} t1={154.2} x={900} y={210} w={940} rot={1} pin={false}>
        {q('মনে করিয়ে না দিলেও যে\nসময়মতো মগ তুলে নেয়,\n{দায়িত্ব} আসলে তারই।')}
      </Card>

      {t > 152.4 && (
        <div
          style={{
            position: 'absolute',
            left: 1370,
            top: 850,
            transform: `translate(-50%,-50%) scale(${chip})`,
            fontFamily,
            fontWeight: 700,
            fontSize: 54,
            color: '#fff',
            background: '#2E9E5B',
            border: '5px solid #222',
            borderRadius: 999,
            padding: '6px 40px 12px',
            whiteSpace: 'nowrap',
          }}
        >
          তোমার ‘মগ’ কোনটা?
        </div>
      )}
    </SceneFrame>
  );
};
