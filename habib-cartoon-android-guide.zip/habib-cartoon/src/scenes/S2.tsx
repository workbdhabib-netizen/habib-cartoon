import React from 'react';
import {useT, kf, usePop} from '../lib';
import {speaking} from '../timeline';
import {Character, Hold, Mood} from '../Character';
import {Sapling} from '../Props';
import {VerandaBack, VerandaFront} from '../Backgrounds';
import {Icon} from '../Icons';
import {Bubble, Captions, NameBadge, SceneFrame, Stage, Cam} from '../Overlays';

const SC = 1.6;
const FY = 930;

// দৃশ্য ২ — দাদুর উপহার: চারা আর মগ
export const S2: React.FC<{dur: number}> = ({dur}) => {
  const t = useT();
  const potPop = usePop(12.4);
  const dTalk = speaking(t, [4, 5, 6]);

  // হাবিব ঢুকছে
  const hx = kf(t, [[11.55, 2250], [13.5, 1420]]);
  const hWalk = t < 13.5 ? 1 : 0;
  const gave = t > 17.7; // মগ হস্তান্তর
  const dHold: Hold = gave ? 'none' : 'mug';
  const hHold: Hold = gave ? 'mug' : 'none';

  const dArm = kf(t, [[11.55, 6], [12.2, 6], [12.7, 62], [14.6, 62], [15.2, 8], [15.8, 8], [16.4, 96], [19, 96], [20.5, 12]]);
  const hArm = kf(t, [[16.4, 6], [17.0, 86], [19.3, 86], [20.4, 8]]);
  const zoom = kf(t, [[11.55, 1], [19.5, 1.06], [21, 1.1]]);

  let hMood: Mood = 'neutral';
  if (t > 15) hMood = 'happy';
  if (t > 25.7) hMood = 'excited';
  const dMood: Mood = t > 25.7 ? 'happy' : 'happy';

  return (
    <SceneFrame dur={dur}>
      <Cam zoom={zoom} cx={1180} cy={620}>
        <Stage>
          <VerandaBack />
          <VerandaFront />
          <g opacity={potPop}>
            <Sapling x={1180} y={FY - 4} scale={1.5 * Math.min(1, 0.4 + potPop * 0.6)} droop={0} sway={t * 30} />
          </g>
          <Character
            kind="dadu"
            x={940}
            y={FY}
            scale={SC}
            mood={dMood}
            talking={dTalk}
            armR={dArm}
            holdR={dHold}
            holdL="cane"
            armL={4}
            seed={1}
          />
          <Character
            kind="habib"
            x={hx}
            y={FY}
            scale={SC}
            mood={hMood}
            walk={hWalk as 0 | 1}
            armL={t < 13.5 ? undefined : hArm}
            holdL={hHold}
            hop={t > 25.7 ? 14 : 0}
            look={t > 13.5 && t < 19 ? -0.7 : 0}
            seed={3}
          />
        </Stage>
      </Cam>

      <NameBadge t0={11.9} t1={14.6} x={940} y={175} text="দাদু" color="#7A5AC8" />
      <NameBadge t0={13.0} t1={15.4} x={1420} y={262} text="হাবিব" color="#E0A400" />

      <Icon name="mug" x={1180} y={300} size={110} t0={22.9} t1={25.2} />
      <Icon name="sun" x={1330} y={300} size={110} t0={23.2} t1={25.2} spin={30} />
      <Icon name="lau" x={1210} y={290} size={120} t0={25.8} t1={27.7} rot={12} />

      <Bubble t0={19.85} t1={22.35} x={600} y={215} w={640} h={190} tx={850} ty={400} text={'দাদুভাই, এই চারাটা\nআজ থেকে তোমার।'} />
      <Bubble t0={22.9} t1={25.35} x={600} y={215} w={640} h={190} tx={850} ty={400} text={'রোজ সকালে এক মগ\nপানি, ব্যস।'} />
      <Bubble t0={25.75} t1={27.6} x={600} y={215} w={640} h={190} tx={850} ty={400} text={'আমি ফিরে এসে\nলাউ খাব কিন্তু।'} />

      <Captions
        items={[
          {t0: 11.9, t1: 15.5, text: 'বারান্দার কোণে {লাউয়ের চারা}'},
          {t0: 15.7, t1: 19.4, text: 'হাবিবের হাতে ছোট্ট {মগ}'},
        ]}
      />
    </SceneFrame>
  );
};
