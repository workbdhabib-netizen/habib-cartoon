import React from 'react';
import {useT, kf} from '../lib';
import {speaking} from '../timeline';
import {Character, Mood} from '../Character';
import {Sapling} from '../Props';
import {VerandaBack, VerandaFront} from '../Backgrounds';
import {Icon} from '../Icons';
import {Bubble, Captions, SceneFrame, Stage, Cam, Stamp} from '../Overlays';

const SC = 1.6;
const FY = 930;

// দৃশ্য ৭ — দাদুর ফেরা, সত্যি কথা, তিনটে নতুন পাতা
export const S7: React.FC<{dur: number}> = ({dur}) => {
  const t = useT();

  // দাদু
  const dx = kf(t, [[122.5, -220], [124.7, 330], [135.4, 330], [137.6, 760], [138.9, 760], [139.4, 800]], false);
  const dWalk: 0 | 1 = t < 124.7 || (t > 135.4 && t < 137.6) ? 1 : 0;
  const dArmR = kf(t, [[139.3, 8], [139.9, 118], [141.5, 118], [142.0, 8]]);
  const dTalk = speaking(t, [38]);

  // হাবিব
  const hx = kf(t, [[122.5, 1000], [124.2, 640], [135.3, 640], [137.3, 1060]], false);
  const hWalk: 0 | 1 = (t > 122.5 && t < 124.2) || (t > 135.3 && t < 137.3) ? 1 : 0;
  let hMood: Mood = 'nervous';
  if (t > 129.8) hMood = 'sad';
  if (t > 133.7) hMood = 'relieved';
  if (t > 135.7) hMood = 'excited';
  const hArms = t > 127 && t < 133 ? 110 : undefined;
  const hArmR = t > 133.7 && t < 135.3 ? 95 : hArms;
  const hTalk = speaking(t, [33, 34, 35]);

  const fresh = kf(t, [[136.3, 0], [137.4, 1]]);
  const zoom = kf(t, [[135.5, 1], [136.6, 1.4], [139.0, 1.4], [140.2, 1.12], [145.6, 1.12]]);

  return (
    <SceneFrame dur={dur}>
      <Cam zoom={zoom} cx={1100} cy={700}>
        <Stage>
          <VerandaBack />
          <VerandaFront />
          <Sapling x={1180} y={FY - 4} scale={1.5} droop={0.05} fresh={fresh} sway={t * 30} />
          <Character
            kind="dadu"
            x={dx}
            y={FY}
            scale={SC}
            mood="happy"
            walk={dWalk}
            talking={dTalk}
            holdL="cane"
            armL={4}
            armR={dWalk ? undefined : dArmR}
            seed={1}
          />
          <Character
            kind="habib"
            x={hx}
            y={FY}
            scale={SC}
            mood={hMood}
            walk={hWalk}
            talking={hTalk}
            armL={hArms}
            armR={hArmR}
            hop={t > 138 ? 10 : 0}
            look={t < 127 ? 0 : t > 137.4 ? 0.6 : -0.5}
            seed={3}
          />
        </Stage>
      </Cam>

      <Icon name="sparkle" x={1110} y={470} size={100} t0={136.8} t1={139.0} spin={50} />
      <Icon name="sparkle" x={1280} y={420} size={80} t0={137.1} t1={139.0} spin={-50} />
      <Icon name="heart" x={1180} y={300} size={120} t0={142.5} t1={145.4} pulse />

      <Bubble t0={127.55} t1={129.4} x={700} y={165} w={620} h={190} tx={650} ty={340} text={'দাদু, একটা কথা\nআগে বলি।'} />
      <Bubble t0={129.85} t1={133.4} x={780} y={165} w={900} h={200} tx={660} ty={340} text={'তৃতীয় দিনে আমি পানি দিইনি,\nগাছটা প্রায় মরে যাচ্ছিল।'} size={50} />
      <Bubble t0={133.85} t1={135.4} x={700} y={165} w={640} h={190} tx={650} ty={340} text={'এখন ঠিক হয়ে গেছে,\nদেখো।'} />
      <Bubble
        t0={141.85}
        t1={145.5}
        x={720}
        y={165}
        w={940}
        h={210}
        tx={800}
        ty={340}
        text={'লাউয়ের চেয়ে এই সত্যি কথাটাই\nবেশি মিষ্টি লাগল, দাদুভাই।'}
        size={50}
      />

      <Stamp t0={136.5} t1={138.95} x={960} y={200} text="৩টি নতুন পাতা" color="#2E9E5B" rot={-5} size={72} />

      <Captions
        items={[
          {t0: 122.75, t1: 125.1, text: '{এক সপ্তাহ পর} দাদু ফিরলেন'},
          {t0: 125.45, t1: 127.2, text: 'দরজাতেই {আটকে} দিল'},
          {t0: 139.5, t1: 141.5, text: 'দাদু {মাথায় হাত} রাখলেন'},
        ]}
      />
    </SceneFrame>
  );
};
