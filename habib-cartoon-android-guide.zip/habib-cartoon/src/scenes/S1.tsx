import React from 'react';
import {AbsoluteFill} from 'remotion';
import {useT, kf} from '../lib';
import {Character} from '../Character';
import {Sapling} from '../Props';
import {Icon} from '../Icons';
import {Bubble, Captions, Card, NameBadge, SceneFrame, Stage} from '../Overlays';
import {fontFamily} from '../theme';

// দৃশ্য ১ — হুক: ক্লিন মোশন গ্রাফিক্স (ক্যারেক্টার ছাড়া শুরু, শেষে শিরোনাম কার্ড)
export const S1: React.FC<{dur: number}> = ({dur}) => {
  const t = useT();
  const sx = kf(t, [[6.5, 960], [7.5, 420]]);
  const sc = kf(t, [[6.5, 1.8], [7.5, 1.55]]);
  const droop = kf(t, [[0, 0], [6.4, 0.7]]);
  const yellow = kf(t, [[2, 0], [6.4, 0.45]]);
  const hop = kf(t, [[7.4, 0], [7.6, 1]]) > 0 ? 18 : 0;

  return (
    <SceneFrame dur={dur} bg="#F8E3B5">
      <AbsoluteFill style={{background: 'radial-gradient(circle at 50% 45%, #FFF6DE 0%, #F8E3B5 68%, #EBCB8B 100%)'}} />
      <Stage>
        {/* নরম মাটি-রেখা */}
        <ellipse cx={960} cy={985} rx={820} ry={46} fill="rgba(160,110,50,0.18)" />
        <Sapling x={sx} y={970} scale={sc} droop={droop} yellow={yellow} sway={t * 30} />
        {t > 7.3 && (
          <Character
            kind="habib"
            x={1530}
            y={985}
            scale={1.65}
            mood={t > 7.4 ? 'happy' : 'neutral'}
            holdL="mug"
            armL={85}
            hop={hop}
            seed={2}
          />
        )}
      </Stage>

      <Icon name="sun" x={330} y={230} size={150} t0={1.3} t1={5.2} spin={25} />
      <Icon name="drop" x={1560} y={380} size={120} t0={3.2} t1={5.3} pulse />
      <Icon name="question" x={1700} y={250} size={100} t0={3.6} t1={5.3} pulse />

      <Bubble kind="think" t0={5.3} t1={6.9} x={1130} y={215} w={720} h={140} tx={1000} ty={400} text="আমার তেষ্টা পেয়েছে?" />

      {/* শিরোনাম কার্ড */}
      <Card t0={7.05} t1={11.3} x={610} y={290} w={760} rot={-2}>
        <div style={{fontFamily, fontWeight: 600, fontSize: 40, color: '#8A5A2B', textAlign: 'center'}}>আজকের গল্প</div>
        <div style={{fontFamily, fontWeight: 700, fontSize: 88, textAlign: 'center', lineHeight: 1.15, marginTop: 6}}>
          চারাগাছ আর <span style={{color: '#E0453A'}}>হাবিব</span>
        </div>
      </Card>
      <NameBadge t0={7.8} t1={10.6} x={1530} y={330} text="হাবিব" color="#E0A400" />

      <Captions
        items={[
          {t0: 1.3, t1: 5.1, text: 'ছোট্ট {চারাগাছ} মুখ ফুটে বলে না'},
        ]}
      />
    </SceneFrame>
  );
};
