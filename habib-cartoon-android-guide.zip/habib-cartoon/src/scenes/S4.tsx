import React from 'react';
import {useT, kf} from '../lib';
import {speaking} from '../timeline';
import {Character, Hold, Mood} from '../Character';
import {Sapling, MugProp, Stream} from '../Props';
import {VerandaBack, VerandaFront} from '../Backgrounds';
import {Icon} from '../Icons';
import {Bubble, Captions, SceneFrame, Stage, Cam} from '../Overlays';

const SC = 1.6;
const FY = 930;

// দৃশ্য ৪ — নেতিয়ে পড়া চারা, পানি জমে থাকা, সাজিদের ফন্দি
export const S4: React.FC<{dur: number}> = ({dur}) => {
  const t = useT();
  const noon = t > 65.3;

  const hx = kf(t, [[57.0, -250], [58.1, 860]], false);
  const walk: 0 | 1 = t < 58.1 ? 1 : 0;
  const hasMug = t > 61.5;
  const hold: Hold = hasMug ? 'mug' : 'none';
  const armR = kf(t, [[61.5, 8], [62.2, 98], [64.8, 98], [65.4, 10]]);
  let mood: Mood = 'surprised';
  if (t > 59.4) mood = 'worried';
  if (t > 65.3) mood = 'sad';

  const shake = t > 58.1 && t < 58.7 ? 7 : 0;
  const zoom = kf(t, [[57, 1], [58.8, 1.22], [60, 1.5], [62, 1.5], [65, 1.25], [67.5, 1.05], [71.6, 1.0]]);

  const droop = kf(t, [[57, 0.75], [60, 0.85], [65.3, 0.85], [66.5, 1]]);
  const yellow = kf(t, [[57, 0.4], [60, 0.85], [66.5, 1]]);
  const water = kf(t, [[62.8, 0], [63.6, 1]]);

  const sjY = kf(t, [[66.9, 1180], [67.4, 924]]);
  const sjTalk = speaking(t, [17, 18]);

  return (
    <SceneFrame dur={dur}>
      <Cam zoom={zoom} cx={1180} cy={700} shake={shake}>
        <Stage>
          <VerandaBack />
          {t > 66.9 && (
            <Character
              kind="sajid"
              x={1580}
              y={sjY}
              scale={SC}
              mood="smug"
              talking={sjTalk}
              holdR="bat"
              armR={30}
              armL={t > 68.8 ? 140 : 8}
              seed={5}
            />
          )}
          <VerandaFront tint={noon ? 'rgba(255,214,90,0.2)' : undefined} />
          <Sapling x={1180} y={FY - 4} scale={1.5} droop={droop} yellow={yellow} hard water={water} sway={t * 30} />
          {!hasMug && <MugProp x={1050} y={FY} scale={1.1} rot={-8} />}
          <Character
            kind="habib"
            x={hx}
            y={FY}
            scale={SC}
            mood={mood}
            walk={walk}
            holdR={hold}
            armR={walk ? undefined : armR}
            tremble={t > 58.1 && t < 59.3 ? 2.5 : 0}
            look={walk ? 0 : 0.9}
            seed={3}
          />
          <Stream t={t} t0={62.4} t1={63.5} x1={1175} y1={600} x2={1185} y2={790} />
          <Stream t={t} t0={63.6} t1={64.7} x1={1175} y1={600} x2={1185} y2={790} />
        </Stage>
      </Cam>

      <Icon name="warning" x={1180} y={330} size={120} t0={59.9} t1={61.9} pulse />
      <Icon name="sun" x={520} y={230} size={190} t0={65.3} t1={71.4} spin={20} />
      <Icon name="clock" x={760} y={250} size={130} t0={65.5} t1={67.1} />
      <Icon name="bulb" x={1700} y={170} size={120} t0={68.9} t1={71.3} pulse />

      <Bubble t0={67.45} t1={68.4} x={1120} y={200} w={560} h={130} tx={1480} ty={410} text="গাছটা তো গেল রে।" />
      <Bubble
        t0={68.85}
        t1={71.45}
        x={1010}
        y={190}
        w={800}
        h={220}
        tx={1480}
        ty={410}
        kind="whisper"
        text={'চল, নতুন একটা চারা কিনে এনে\nবসিয়ে দিই, দাদু টেরই পাবে না।'}
        size={50}
      />

      <Captions
        items={[
          {t0: 57.25, t1: 59.25, text: '{পরদিন} সকালে থমকে দাঁড়াল'},
          {t0: 59.75, t1: 61.8, text: 'পাতা {নুয়ে}, কিনারা হলদে'},
          {t0: 62.3, t1: 63.7, text: 'তাড়াহুড়োয় {দু মগ} পানি'},
          {t0: 63.8, t1: 65.0, text: 'পানি {জমে} রইল'},
          {t0: 65.35, t1: 67.15, text: 'দুপুরে আরও {নেতিয়ে} পড়ল'},
        ]}
      />
    </SceneFrame>
  );
};
