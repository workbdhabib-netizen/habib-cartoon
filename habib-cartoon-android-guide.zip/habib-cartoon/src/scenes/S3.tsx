import React from 'react';
import {useT, kf} from '../lib';
import {speaking} from '../timeline';
import {Character, Hold, Mood} from '../Character';
import {Sapling, MugProp, Stream, TableMeal} from '../Props';
import {VerandaBack, VerandaFront} from '../Backgrounds';
import {Icon} from '../Icons';
import {Bubble, Captions, NameBadge, SceneFrame, Stage} from '../Overlays';

const SC = 1.6;
const FY = 930;

// দৃশ্য ৩ — প্রথম দুদিন, সাজিদের ডাক, হাবিবের দৌড়, বিকেলে খাওয়া
export const S3: React.FC<{dur: number}> = ({dur}) => {
  const t = useT();
  const evening = t > 50.7;

  // হাবিব
  let hx = 930;
  let walk: 0 | 1 | 2 = 0;
  let hold: Hold = 'mug';
  let armR: number | undefined = undefined;
  let armL: number | undefined = undefined;
  let mood: Mood = 'happy';
  let sit = false;
  let look = 0;
  let lean = 0;

  if (t < 39.8) {
    // ওপরে-নিচে পানি ঢালা
    const pour1 = t > 28.6 && t < 30.9;
    const pour2 = t > 31.6 && t < 33.7;
    armR = kf(t, [[28, 8], [28.6, 98], [30.9, 98], [31.3, 30], [31.6, 98], [33.7, 98], [34.2, 10]]);
    armL = t > 33.3 && t < 35.4 ? 70 : 8;
    lean = pour1 || pour2 ? 6 : 0;
    look = 0.8;
    if (t > 35.76) {
      mood = 'surprised';
      look = 1;
    }
  } else if (t < 47.6) {
    mood = t < 43 ? 'excited' : 'worried';
    look = 1;
    armL = kf(t, [[40, 8], [41, 70], [42, 8], [43, 8]]);
    armR = 8;
  } else if (t < 51.1) {
    // মগ নামিয়ে রেখে দৌড়
    hold = t < 48.0 ? 'mug' : 'none';
    armR = t < 48.0 ? kf(t, [[47.6, 98], [48.0, 40]]) : undefined;
    if (t > 48.4) {
      walk = 2;
      hx = kf(t, [[48.4, 930], [50.4, -300]], false);
      lean = -9;
    }
    mood = 'excited';
  } else {
    // বিকেল: ঢুকে খেতে বসে
    hold = 'spoon';
    if (t < 52.0) {
      walk = 1;
      hx = kf(t, [[51.12, -250], [52.0, 640]], false);
      hold = 'none';
    } else {
      hx = 640;
      sit = true;
      armR = 110 + Math.sin(t * 5) * 38;
      look = -1;
    }
    mood = 'happy';
  }

  // সাজিদ জানালায়
  const sjY = kf(t, [[35.6, 1180], [36.1, 924], [48.8, 924], [49.4, 1180]]);
  const showSajid = t > 35.6 && t < 49.5;
  const sjArm = 140 + Math.sin(t * 7) * 18;
  const sjTalk = speaking(t, [9, 10]);

  const mugOnFloor = t > 48.0;
  const droop = kf(t, [[27.85, 0], [50, 0.05], [57, 0.22]]);
  const yellow = kf(t, [[50, 0], [57, 0.15]]);

  return (
    <SceneFrame dur={dur}>
      <Stage>
        <VerandaBack dusk={evening ? 1 : 0} />
        {showSajid && (
          <Character
            kind="sajid"
            x={1580}
            y={sjY}
            scale={SC}
            mood="excited"
            talking={sjTalk}
            holdR="bat"
            armR={sjArm}
            armL={t > 40 ? 150 : 8}
            seed={5}
          />
        )}
        <VerandaFront tint={evening ? 'rgba(255,150,50,0.2)' : undefined} />
        <Sapling x={1180} y={FY - 4} scale={1.5} droop={droop} yellow={yellow} sway={t * 30} />
        {mugOnFloor && <MugProp x={1050} y={FY} scale={1.1} rot={-8} />}
        {evening && <TableMeal x={640} y={FY + 6} scale={1.5} />}
        <Character
          kind="habib"
          x={hx}
          y={FY}
          scale={SC}
          mood={mood}
          walk={walk}
          holdR={hold}
          armR={armR}
          armL={armL}
          sit={sit}
          look={look}
          lean={lean}
          seed={3}
        />
        <Stream t={t} t0={28.6} t1={30.9} x1={1175} y1={600} x2={1185} y2={790} />
        <Stream t={t} t0={31.6} t1={33.7} x1={1175} y1={600} x2={1185} y2={790} />
      </Stage>

      <Icon name="calendar" x={640} y={300} size={120} t0={28.9} t1={32.0} />
      <Icon name="calendar" x={790} y={300} size={120} t0={31.5} t1={34.5} />
      <Icon name="leaf" x={1180} y={470} size={100} t0={33.4} t1={35.3} pulse />

      <NameBadge t0={36.0} t1={38.8} x={1580} y={235} text="সাজিদ" color="#2E9E5B" />

      <Bubble t0={40.1} t1={42.9} x={1090} y={190} w={560} h={130} tx={1470} ty={400} text="হাবিব, জলদি আয়!" />
      <Bubble t0={43.2} t1={45.0} x={1090} y={190} w={600} h={190} tx={1470} ty={400} text={'মাঠ দখল\nহয়ে যাবে!'} />

      <Captions
        items={[
          {t0: 28.1, t1: 31.6, text: '{প্রথম দুদিন} মগ ভরে পানি'},
          {t0: 31.9, t1: 35.25, text: 'টবের পাশে {পাতা গুনে} নিল'},
          {t0: 35.9, t1: 39.7, text: 'জানালার নিচে {সাজিদ}, হাতে ব্যাট'},
          {t0: 47.7, t1: 50.7, text: 'মগ নামিয়ে {এক দৌড়ে}'},
          {t0: 51.2, t1: 53.4, text: '{বিকেলে} ফিরে খেতে বসল'},
          {t0: 53.9, t1: 56.8, text: 'বারান্দার দিকে {তাকাল না}'},
        ]}
      />
    </SceneFrame>
  );
};
