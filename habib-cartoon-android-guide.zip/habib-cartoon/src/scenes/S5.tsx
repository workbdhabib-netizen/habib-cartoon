import React from 'react';
import {useT, kf} from '../lib';
import {speaking} from '../timeline';
import {Character, Hold, Mood} from '../Character';
import {CounterFront} from '../Props';
import {NurseryBack} from '../Backgrounds';
import {Icon} from '../Icons';
import {Bubble, Captions, NameBadge, SceneFrame, Stage} from '../Overlays';

const SC = 1.6;
const FY = 1000;

// দৃশ্য ৫ — নার্সারিতে হাবিব ও কাকা রহিম
export const S5: React.FC<{dur: number}> = ({dur}) => {
  const t = useT();

  // হাবিব
  let hx = 900;
  let walk: 0 | 1 | 2 = 0;
  let hold: Hold = 'money';
  let armR: number | undefined = undefined;
  let mood: Mood = 'nervous';
  let lean = 0;
  let look = 0;
  if (t < 73.7) {
    walk = 1;
    hx = kf(t, [[71.6, -200], [73.7, 820]], false);
    mood = 'focused';
  } else if (t < 78.4) {
    walk = 1;
    hx = kf(t, [[73.7, 820], [78.4, 990]], false);
    if (t > 77.6) walk = 0;
  } else if (t < 92.6) {
    hx = 990;
    if (t < 80.0) {
      hold = 'none';
      armR = kf(t, [[78.4, 10], [79.0, 70], [79.8, 70], [80.1, 10]]);
    } else if (t < 82.0) {
      hold = 'phone';
      armR = 140;
    } else {
      hold = 'none';
      armR = 10;
    }
    mood = t > 87.4 ? 'relieved' : 'nervous';
    look = 0.6;
  } else {
    // টাকা পকেটে, দৌড়
    walk = 2;
    hold = 'none';
    hx = kf(t, [[93.6, 990], [98.6, -250]], false);
    if (t < 93.6) {
      walk = 0;
      hx = 990;
    }
    lean = -8;
    mood = 'happy';
    look = -1;
  }

  const rTalk = speaking(t, [22, 23, 24]);
  const rMood: Mood = t < 82.3 ? 'neutral' : t < 84.2 ? 'surprised' : 'happy';
  const rArm = 10 + Math.sin(t * 6) * 8;

  const sjX = kf(t, [[96.56, 1900], [97.6, 1330]], false);
  const sjWalk: 0 | 1 = t < 97.6 ? 1 : 0;

  // টাকার আইকন কাউন্টারে যাওয়া / ফেরত
  const coinX = kf(t, [[78.3, 1080], [79.4, 1250], [92.5, 1250], [93.6, 990]]);
  const coinY = kf(t, [[78.3, 640], [79.4, 676], [92.5, 676], [93.6, 700]]);

  return (
    <SceneFrame dur={dur}>
      <Stage>
        <NurseryBack />
        <Character
          kind="rahim"
          x={1560}
          y={FY}
          scale={SC}
          mood={rMood}
          talking={rTalk}
          armR={rArm}
          armL={t > 87.4 ? 100 : 12}
          seed={7}
        />
        <CounterFront />
        <Character
          kind="habib"
          x={hx}
          y={FY}
          scale={SC}
          mood={mood}
          walk={walk}
          holdR={hold}
          armR={armR}
          lean={lean}
          look={look}
          seed={3}
        />
        {t > 96.56 && (
          <Character
            kind="sajid"
            x={sjX}
            y={FY}
            scale={SC}
            mood="excited"
            walk={sjWalk}
            talking
            armL={150}
            armR={150}
            seed={5}
          />
        )}
      </Stage>

      <Icon name="coin" x={hx} y={300} size={130} t0={71.85} t1={73.3} float={10} />
      <Icon name="coin" x={coinX} y={coinY} size={90} t0={78.35} t1={93.5} float={0} rot={-8} />
      <Icon name="spoon" x={1010} y={430} size={110} t0={88.2} t1={90.2} />
      <Icon name="drop" x={1160} y={430} size={100} t0={90.3} t1={91.9} pulse />

      <NameBadge t0={73.9} t1={76.6} x={1560} y={250} text="কাকা রহিম" color="#8E2A3A" />

      <Bubble t0={82.35} t1={84.15} x={1220} y={210} w={640} h={160} tx={1500} ty={400} text={'আরে, এ তো\nমরেনি রে বাবা।'} />
      <Bubble t0={84.7} t1={87.0} x={1220} y={210} w={700} h={190} tx={1500} ty={400} text={'পানি ঢুকতে না পারলে\nমাটি শক্ত হয়ে যায়।'} />
      <Bubble
        t0={87.55}
        t1={92.0}
        x={1180}
        y={200}
        w={880}
        h={210}
        tx={1500}
        ty={400}
        text={'মাটিটা চামচ দিয়ে আলগা করে দাও,\nতারপর রোজ সকালে অল্প অল্প পানি।'}
        size={50}
      />

      <Captions
        items={[
          {t0: 71.8, t1: 73.35, text: '{বিশ টাকা} নিয়ে নার্সারিতে'},
          {t0: 73.7, t1: 77.5, text: 'দোকানদার {কাকা রহিম} মাটি মেশাচ্ছেন'},
          {t0: 78.0, t1: 79.9, text: '{টাকা} কাউন্টারে রেখে'},
          {t0: 80.0, t1: 81.95, text: '{ফোনে} চারার ছবি দেখাল'},
          {t0: 92.5, t1: 96.1, text: 'টাকা {পকেটে}, বাড়ির দিকে ছুট'},
          {t0: 96.6, t1: 99.8, text: 'সাজিদ ডাকল, {ফিরে তাকাল না}'},
        ]}
      />
    </SceneFrame>
  );
};
