import React from 'react';
import {useT, kf} from '../lib';
import {Character, Hold} from '../Character';
import {Sapling, Bag, Stream} from '../Props';
import {VerandaBack, VerandaFront} from '../Backgrounds';
import {Icon, IconSvg} from '../Icons';
import {Captions, Card, NameBadge, SceneFrame, Stage} from '../Overlays';
import {usePop} from '../lib';
import {fontFamily} from '../theme';

const SC = 1.6;
const FY = 930;

const Row: React.FC<{t0: number; doneAt: number; num: string; text: string}> = ({t0, doneAt, num, text}) => {
  const t = useT();
  const pop = usePop(t0);
  const tick = usePop(doneAt);
  if (t < t0) return null;
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 18, marginTop: 14, opacity: pop, transform: `translateX(${(1 - pop) * 40}px)`}}>
      <div style={{fontFamily, fontWeight: 700, fontSize: 46, color: '#E0453A', width: 40}}>{num}</div>
      <div style={{fontFamily, fontWeight: 600, fontSize: 44, flex: 1, lineHeight: 1.2}}>{text}</div>
      <div style={{transform: `scale(${tick})`, width: 52, height: 52}}>
        <IconSvg name="check" size={52} />
      </div>
    </div>
  );
};

// দৃশ্য ৬ — মাটি আলগা, অল্প পানি, লাল ফিতে (রহিম কাকার টিপস ৩ ধাপে)
export const S6: React.FC<{dur: number}> = ({dur}) => {
  const t = useT();
  const standing = t > 113.0;

  let hx = 940;
  let walk: 0 | 1 = 0;
  if (t > 113.0) {
    hx = kf(t, [[113.0, 940], [114.6, 620]], false);
    walk = t < 114.6 ? 1 : 0;
  }
  const hold: Hold = t < 106.3 ? 'spoon' : t < 112.6 ? 'mug' : 'none';
  let armR: number | undefined;
  if (t < 106.3) armR = 55 + Math.sin(t * 8) * 12;
  else if (t < 112.6) armR = kf(t, [[106.3, 20], [107.0, 80], [111.5, 80], [112.5, 20]]);
  else armR = 8;
  const armL = standing && !walk ? 52 + Math.sin(t * 6) * 5 : undefined;

  const hard = t < 104.6;
  const water = kf(t, [[106.9, 0], [107.8, 0.95], [110.8, 0.9], [112.2, 0]]);
  const droop = kf(t, [[100, 1], [112, 0.9], [122, 0.7]]);
  const ribbon = kf(t, [[115.3, 0], [116.0, 1]]);

  const momOp = kf(t, [[119.3, 0], [119.7, 1]]);

  return (
    <SceneFrame dur={dur}>
      <Stage>
        <VerandaBack />
        <VerandaFront />
        <Sapling x={1180} y={FY - 4} scale={1.5} droop={droop} yellow={0.5} hard={hard} water={water} sway={t * 30} />
        <Bag x={400} y={FY + 4} scale={1.5} ribbon={ribbon} />
        <Character
          kind="habib"
          x={hx}
          y={FY}
          scale={SC}
          mood={t < 113 ? 'focused' : t < 116 ? 'happy' : 'excited'}
          walk={walk}
          holdR={hold}
          armR={armR}
          armL={armL}
          sit={!standing}
          look={standing ? -0.8 : 0.8}
          hop={t > 116.5 ? 8 : 0}
          seed={3}
        />
        {momOp > 0 && <Character kind="ma" x={300} y={FY} scale={SC} mood="happy" opacity={momOp} seed={9} />}
        <Stream t={t} t0={107.0} t1={110.8} x1={1175} y1={720} x2={1185} y2={790} n={3} />
      </Stage>

      <Icon name="drop" x={1180} y={520} size={90} t0={108.0} t1={110.5} pulse />
      <Icon name="bulb" x={640} y={330} size={110} t0={116.2} t1={118.8} pulse />

      <Card t0={100.3} t1={119.3} x={500} y={70} w={640} rot={1}>
        <div style={{fontFamily, fontWeight: 700, fontSize: 50, textAlign: 'center', color: '#2E9E5B'}}>ধাপে ধাপে</div>
        <Row t0={100.9} doneAt={105.2} num="১" text="চামচে মাটি আলগা" />
        <Row t0={106.6} doneAt={111.4} num="২" text="অল্প অল্প পানি" />
        <Row t0={113.1} doneAt={116.4} num="৩" text="লাল ফিতে, চোখে পড়বে" />
      </Card>

      <NameBadge t0={119.7} t1={122.2} x={300} y={225} text="মা" color="#D9578B" />
      <Captions items={[{t0: 119.6, t1: 122.3, text: 'মা কিছু বললেন না, {হাসলেন}'}]} />
    </SceneFrame>
  );
};
