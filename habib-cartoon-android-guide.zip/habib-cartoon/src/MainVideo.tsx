import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import './theme';
import {SceneCtx} from './lib';
import {FPS, SCENES} from './timeline';
import {S1} from './scenes/S1';
import {S2} from './scenes/S2';
import {S3} from './scenes/S3';
import {S4} from './scenes/S4';
import {S5} from './scenes/S5';
import {S6} from './scenes/S6';
import {S7} from './scenes/S7';
import {S8} from './scenes/S8';

const COMPS: Record<number, React.FC<{dur: number}>> = {1: S1, 2: S2, 3: S3, 4: S4, 5: S5, 6: S6, 7: S7, 8: S8};

export const MainVideo: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: '#FBE9C6'}}>
      <Audio src={staticFile('voice.mp3')} volume={1} />
      {SCENES.map((s) => {
        const from = Math.round(s.t0 * FPS);
        const dur = Math.round(s.t1 * FPS) - from;
        const C = COMPS[s.id];
        return (
          <Sequence key={s.id} from={from} durationInFrames={dur}>
            <SceneCtx.Provider value={from / FPS}>
              <C dur={dur} />
            </SceneCtx.Provider>
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};
