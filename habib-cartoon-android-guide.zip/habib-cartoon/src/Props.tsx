import React from 'react';
import {INK, SW, fontFamily} from './theme';

const mix = (a: [number, number, number], b: [number, number, number], u: number): string => {
  const c = a.map((v, i) => Math.round(v + (b[i] - v) * u));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
};

interface SaplingProps {
  x: number; // টবের তলার কেন্দ্র
  y: number; // টবের তলা (মাটির লেভেল)
  scale?: number;
  droop?: number; // 0 সতেজ .. 1 পুরো নেতানো
  yellow?: number; // 0..1 হলদে ভাব
  hard?: boolean; // শক্ত ফাটা মাটি
  water?: number; // মাটির ওপর জমা পানি 0..1
  fresh?: number; // ৩টি নতুন পাতা 0..1
  sway?: number; // বাতাসে দোলা (ফ্রেম)
}

// মাটির টবে লাউয়ের চারা
export const Sapling: React.FC<SaplingProps> = ({
  x,
  y,
  scale = 1,
  droop = 0,
  yellow = 0,
  hard = false,
  water = 0,
  fresh = 0,
  sway = 0,
}) => {
  const h = 170 - droop * 70;
  const dx = droop * 70 + Math.sin(sway / 18) * (1 - droop) * 5;
  const soilY = -126;
  const topX = dx;
  const topY = soilY - h;
  const leafColor = mix([84, 178, 79], [201, 178, 50], yellow);
  const leafDark = mix([58, 140, 60], [160, 140, 40], yellow);
  const leafAng = -28 + droop * 118;

  const pt = (u: number): [number, number] => {
    // quadratic bezier M0,soilY Q dx*0.15,soilY-h*0.6 dx,topY
    const cx = dx * 0.15;
    const cy = soilY - h * 0.6;
    const bx = (1 - u) * (1 - u) * 0 + 2 * (1 - u) * u * cx + u * u * topX;
    const by = (1 - u) * (1 - u) * soilY + 2 * (1 - u) * u * cy + u * u * topY;
    return [bx, by];
  };

  const leaf = (u: number, side: -1 | 1, size: number, key: string) => {
    const [px, py] = pt(u);
    return (
      <g key={key} transform={`translate(${px},${py}) scale(${side},1) rotate(${leafAng + (side === 1 ? 0 : 6)})`}>
        <path
          d={`M0 0 Q${size * 0.4} ${-size * 0.46} ${size} 0 Q${size * 0.4} ${size * 0.46} 0 0Z`}
          fill={leafColor}
          stroke={INK}
          strokeWidth={SW}
          strokeLinejoin="round"
        />
        <path d={`M4 0 Q${size * 0.5} ${-2} ${size * 0.9} 0`} fill="none" stroke={leafDark} strokeWidth={3} />
      </g>
    );
  };

  const [tx, ty] = pt(1);

  return (
    <g transform={`translate(${x},${y}) scale(${scale})`}>
      {/* টব */}
      <path d="M-78 -112 L78 -112 L58 -6 Q0 6 -58 -6 Z" fill="#C8683A" stroke={INK} strokeWidth={SW + 0.5} strokeLinejoin="round" />
      <path d="M-66 -70 L66 -70" stroke="#A9532B" strokeWidth={5} opacity={0.6} />
      <rect x={-92} y={-142} width={184} height={36} rx={12} fill="#D87A48" stroke={INK} strokeWidth={SW + 0.5} />
      {/* মাটি */}
      <ellipse cx={0} cy={soilY + 4} rx={80} ry={15} fill={hard ? '#8A6B50' : '#5B3A29'} stroke={INK} strokeWidth={SW} />
      {hard && (
        <path
          d="M-50 -122 l14 6 l-6 8 M10 -126 l16 8 l-4 6 M40 -120 l-12 8 M-14 -118 l8 10"
          stroke="#4A3224"
          strokeWidth={3}
          fill="none"
          strokeLinecap="round"
        />
      )}
      {water > 0 && (
        <g opacity={water}>
          <ellipse cx={0} cy={soilY + 2} rx={66} ry={10} fill="#7FC8F2" stroke="#3E9AD0" strokeWidth={2} />
          <ellipse cx={-20} cy={soilY} rx={14} ry={3} fill="#fff" opacity={0.7} />
        </g>
      )}
      {/* কাণ্ড */}
      <path d={`M0 ${soilY} Q${dx * 0.15} ${soilY - h * 0.6} ${topX} ${topY}`} fill="none" stroke={INK} strokeWidth={15} strokeLinecap="round" />
      <path d={`M0 ${soilY} Q${dx * 0.15} ${soilY - h * 0.6} ${topX} ${topY}`} fill="none" stroke={mix([84, 160, 70], [160, 150, 60], yellow)} strokeWidth={10} strokeLinecap="round" />
      {leaf(0.42, -1, 78, 'a')}
      {leaf(0.55, 1, 82, 'b')}
      {leaf(0.78, -1, 70, 'c')}
      {leaf(0.97, 1, 62, 'd')}
      {/* ডগা: প্যাঁচানো টেন্ড্রিল */}
      <path d={`M${tx} ${ty} q8 -14 -4 -22 q-12 -6 -14 6`} fill="none" stroke="#3F9A45" strokeWidth={4} strokeLinecap="round" />
      {/* ৩টি নতুন পাতা */}
      {fresh > 0 &&
        [-34, 0, 34].map((a, i) => (
          <g key={i} transform={`translate(${tx},${ty}) rotate(${a}) scale(${fresh})`}>
            <path d="M0 0 Q-16 -36 0 -74 Q16 -36 0 0Z" fill="#7BD66B" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
            <path d="M0 -4 V-62" stroke="#4FB04A" strokeWidth={3} />
          </g>
        ))}
    </g>
  );
};

// মাটিতে পড়ে থাকা মগ
export const MugProp: React.FC<{x: number; y: number; scale?: number; rot?: number}> = ({x, y, scale = 1.6, rot = 0}) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${scale})`}>
    <ellipse cx={0} cy={2} rx={34} ry={7} fill="rgba(0,0,0,0.15)" />
    <path d="M24 -44 h12 a14 14 0 0 1 0 34 h-10" fill="none" stroke={INK} strokeWidth={SW + 1} />
    <path d="M-26 -62 H26 V-8 A10 10 0 0 1 16 0 H-16 A10 10 0 0 1 -26 -8 Z" fill="#4A86E8" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
    <rect x={-26} y={-62} width={52} height={11} rx={3} fill="#fff" stroke={INK} strokeWidth={SW} />
  </g>
);

// স্কুলব্যাগ, চেইনে লাল ফিতে (ribbon 0..1)
export const Bag: React.FC<{x: number; y: number; scale?: number; ribbon?: number}> = ({x, y, scale = 1.5, ribbon = 0}) => (
  <g transform={`translate(${x},${y}) scale(${scale})`}>
    <ellipse cx={0} cy={2} rx={72} ry={11} fill="rgba(0,0,0,0.14)" />
    <path d="M-30 -178 Q0 -214 30 -178" fill="none" stroke={INK} strokeWidth={9} strokeLinecap="round" />
    <path d="M-30 -178 Q0 -214 30 -178" fill="none" stroke="#2F62B5" strokeWidth={5} strokeLinecap="round" />
    <rect x={-62} y={-180} width={124} height={176} rx={34} fill="#3A7BD5" stroke={INK} strokeWidth={SW + 0.5} />
    <rect x={-46} y={-98} width={92} height={70} rx={16} fill="#2F62B5" stroke={INK} strokeWidth={SW} />
    <path d="M-40 -150 H40" stroke={INK} strokeWidth={3} strokeDasharray="7 6" />
    <rect x={-6} y={-152} width={12} height={20} rx={4} fill="#C9D0D8" stroke={INK} strokeWidth={SW} />
    {ribbon > 0 && (
      <g transform={`translate(0,-128) scale(${ribbon * 0.62})`}>
        <path d="M0 0 L-34 -22 Q-42 4 -34 26 Z" fill="#E8332F" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
        <path d="M0 0 L34 -22 Q42 4 34 26 Z" fill="#E8332F" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
        <circle cx={0} cy={2} r={9} fill="#C0201C" stroke={INK} strokeWidth={4} />
        <path d="M-4 10 L-14 52 M4 10 L16 52" stroke="#E8332F" strokeWidth={9} strokeLinecap="round" />
      </g>
    )}
  </g>
);

// ছোট টেবিল ও খাবারের প্লেট
export const TableMeal: React.FC<{x: number; y: number; scale?: number}> = ({x, y, scale = 1.5}) => (
  <g transform={`translate(${x},${y}) scale(${scale})`}>
    <rect x={-120} y={-118} width={240} height={22} rx={8} fill="#B9803F" stroke={INK} strokeWidth={SW} />
    <rect x={-104} y={-96} width={16} height={96} fill="#9A6A32" stroke={INK} strokeWidth={SW} />
    <rect x={88} y={-96} width={16} height={96} fill="#9A6A32" stroke={INK} strokeWidth={SW} />
    <ellipse cx={0} cy={-124} rx={64} ry={12} fill="#fff" stroke={INK} strokeWidth={SW} />
    <path d="M-34 -128 Q0 -158 34 -128 Z" fill="#FFFFFF" stroke={INK} strokeWidth={SW} strokeLinejoin="round" />
    <ellipse cx={42} cy={-126} rx={16} ry={6} fill="#E8A13B" stroke={INK} strokeWidth={2} />
  </g>
);

// গাছের দোকানের কাউন্টার (সামনের স্তর) + বালতি
export const CounterFront: React.FC<{bucketSoil?: number}> = ({bucketSoil = 0}) => (
  <g>
    <rect x={1040} y={706} width={840} height={34} rx={8} fill="#D69A58" stroke={INK} strokeWidth={SW + 0.5} />
    <rect x={1060} y={740} width={800} height={340} fill="#A8703C" stroke={INK} strokeWidth={SW + 0.5} />
    <path d="M1100 780 V1080 M1500 780 V1080 M1820 780 V1080" stroke="#8E5C2F" strokeWidth={4} />
    <rect x={1100} y={800} width={350} height={170} rx={10} fill="none" stroke="#8E5C2F" strokeWidth={5} />
    <rect x={1550} y={800} width={250} height={170} rx={10} fill="none" stroke="#8E5C2F" strokeWidth={5} />
    {/* মাটি-ভরা বালতি */}
    <g transform="translate(1560,706)">
      <path d="M-56 -86 L56 -86 L44 0 L-44 0 Z" fill="#7F8A96" stroke={INK} strokeWidth={SW + 0.5} strokeLinejoin="round" />
      <ellipse cx={0} cy={-86} rx={56} ry={11} fill="#5B3A29" stroke={INK} strokeWidth={SW} />
      <path d="M-56 -86 Q0 -150 56 -86" fill="none" stroke={INK} strokeWidth={4} />
      <path d="M-30 -70 L-26 -12" stroke="#fff" strokeWidth={4} opacity={0.4 + bucketSoil * 0} strokeLinecap="round" />
    </g>
  </g>
);

// টেক্সট-সহ ঝোলানো সাইনবোর্ড (SVG)
export const Sign: React.FC<{x: number; y: number; text: string}> = ({x, y, text}) => (
  <g>
    <path d={`M${x - 150} ${y} V${y - 40} M${x + 150} ${y} V${y - 40}`} stroke={INK} strokeWidth={4} />
    <rect x={x - 200} y={y} width={400} height={86} rx={16} fill="#8A5A2B" stroke={INK} strokeWidth={SW + 0.5} />
    <text x={x} y={y + 60} textAnchor="middle" fontFamily={fontFamily} fontWeight={700} fontSize={52} fill="#FFF3D6">
      {text}
    </text>
  </g>
);

// মগ থেকে ঝরে পড়া পানির ফোঁটা (t0..t1 সময়ে)
export const Stream: React.FC<{
  t: number;
  t0: number;
  t1: number;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  n?: number;
}> = ({t, t0, t1, x1, y1, x2, y2, n = 6}) => {
  if (t < t0 || t > t1) return null;
  return (
    <g>
      {Array.from({length: n}).map((_, i) => {
        const ph = (((t - t0) * 2.4 + i / n) % 1 + 1) % 1;
        const cx = x1 + (x2 - x1) * ph;
        const cy = y1 + (y2 - y1) * ph * ph * 0.6 + (y2 - y1) * ph * 0.4;
        return (
          <path
            key={i}
            d="M0 -10 C0 -10 -7 -1 -7 3 A7 7 0 0 0 7 3 C7 -1 0 -10 0 -10Z"
            transform={`translate(${cx},${cy})`}
            fill="#5BB8F0"
            stroke={INK}
            strokeWidth={2}
          />
        );
      })}
    </g>
  );
};
