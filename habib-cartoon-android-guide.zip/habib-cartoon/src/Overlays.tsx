import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {INK, HL, fontFamily, CREAM} from './theme';
import {clamp, useT, usePop, fadeWin} from './lib';

// "টেক্সট {হাইলাইট} টেক্সট" -> রঙিন স্প্যান
const rich = (text: string, hlColor: string): React.ReactNode[] =>
  text.split(/(\{[^}]+\})/g).map((p, i) =>
    p.startsWith('{') ? (
      <span key={i} style={{color: hlColor}}>
        {p.slice(1, -1)}
      </span>
    ) : (
      <span key={i}>{p}</span>
    ),
  );

export interface Cap {
  t0: number;
  t1: number;
  text: string;
}

// নিচের ভাসমান ক্যাপশন (শুধু যখন কোনো বাবল/কার্ড নেই)
export const Captions: React.FC<{items: Cap[]}> = ({items}) => {
  const t = useT();
  const c = items.find((i) => t >= i.t0 && t <= i.t1);
  if (!c) return null;
  const inn = clamp((t - c.t0) / 0.2, 0, 1);
  const out = clamp((c.t1 - t) / 0.15, 0, 1);
  return (
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: 62,
        textAlign: 'center',
        fontFamily,
        fontWeight: 700,
        fontSize: 72,
        color: '#fff',
        WebkitTextStroke: '10px #222',
        paintOrder: 'stroke fill',
        textShadow: '0 7px 0 rgba(0,0,0,0.22)',
        opacity: inn * out,
        transform: `translateY(${(1 - inn) * 26}px) scale(${0.94 + 0.06 * inn})`,
        letterSpacing: 1,
      }}
    >
      {rich(c.text, HL)}
    </div>
  );
};

interface BubbleProps {
  t0: number;
  t1: number;
  x: number; // বাবলের কেন্দ্র
  y: number;
  w: number;
  h: number;
  tx: number; // বক্তার দিকে ইঙ্গিত (লেজের ডগা)
  ty: number;
  text: string;
  kind?: 'speak' | 'think' | 'whisper';
  size?: number;
}

// স্পিচ / থট / ফিসফিস কলআউট বাবল
export const Bubble: React.FC<BubbleProps> = ({t0, t1, x, y, w, h, tx, ty, text, kind = 'speak', size = 54}) => {
  const t = useT();
  const pop = usePop(t0, 13, 180);
  if (t < t0 || t > t1) return null;
  const out = clamp((t1 - t) / 0.18, 0, 1);
  const fill = kind === 'whisper' ? '#FFF6D6' : '#FFFFFF';
  const bx = clamp(tx, x - w / 2 + 64, x + w / 2 - 64);
  const bottom = y + h / 2;
  const rx = kind === 'think' ? Math.min(h / 2, 70) : 36;
  const dash = kind === 'whisper' ? '12 9' : undefined;
  return (
    <svg
      viewBox="0 0 1920 1080"
      width={1920}
      height={1080}
      style={{position: 'absolute', left: 0, top: 0, opacity: out, transform: `scale(${pop})`, transformOrigin: `${tx}px ${ty}px`}}
    >
      {kind === 'think' ? (
        <>
          <circle cx={bx + (tx - bx) * 0.22} cy={bottom + (ty - bottom) * 0.2} r={20} fill={fill} stroke={INK} strokeWidth={4} />
          <circle cx={bx + (tx - bx) * 0.55} cy={bottom + (ty - bottom) * 0.52} r={13} fill={fill} stroke={INK} strokeWidth={4} />
          <circle cx={bx + (tx - bx) * 0.85} cy={bottom + (ty - bottom) * 0.82} r={8} fill={fill} stroke={INK} strokeWidth={4} />
        </>
      ) : (
        <>
          <polygon
            points={`${bx - 26},${bottom - 4} ${bx + 26},${bottom - 4} ${tx},${ty}`}
            fill={fill}
            stroke={INK}
            strokeWidth={4}
            strokeLinejoin="round"
            strokeDasharray={dash}
          />
        </>
      )}
      <rect
        x={x - w / 2}
        y={y - h / 2}
        width={w}
        height={h}
        rx={rx}
        fill={fill}
        stroke={INK}
        strokeWidth={4}
        strokeDasharray={dash}
      />
      {kind !== 'think' && <rect x={bx - 23} y={bottom - 8} width={46} height={9} fill={fill} />}
      <foreignObject x={x - w / 2} y={y - h / 2} width={w} height={h}>
        <div
          style={{
            width: '100%',
            height: '100%',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            textAlign: 'center',
            boxSizing: 'border-box',
            padding: '8px 30px',
            fontFamily,
            fontWeight: 700,
            fontSize: size,
            lineHeight: 1.22,
            color: INK,
            whiteSpace: 'pre-line',
          }}
        >
          <span>{rich(text, '#E0453A')}</span>
        </div>
      </foreignObject>
    </svg>
  );
};

// ক্যারেক্টারের উপরে রঙিন পিল-ব্যাজ
export const NameBadge: React.FC<{t0: number; t1: number; x: number; y: number; text: string; color: string}> = ({
  t0,
  t1,
  x,
  y,
  text,
  color,
}) => {
  const t = useT();
  const pop = usePop(t0, 11, 170);
  if (t < t0 || t > t1) return null;
  const out = clamp((t1 - t) / 0.2, 0, 1);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) scale(${pop})`,
        opacity: out,
        background: color,
        color: '#fff',
        fontFamily,
        fontWeight: 700,
        fontSize: 46,
        padding: '6px 34px 10px',
        borderRadius: 999,
        border: `4px solid ${INK}`,
        boxShadow: '0 6px 0 rgba(0,0,0,0.2)',
        whiteSpace: 'nowrap',
      }}
    >
      {text}
    </div>
  );
};

interface CardProps {
  t0: number;
  t1: number;
  x: number; // বাম-উপরের কোণ
  y: number;
  w: number;
  rot?: number;
  color?: string;
  pin?: boolean;
  children: React.ReactNode;
}

// পিন করা নোট কার্ড
export const Card: React.FC<CardProps> = ({t0, t1, x, y, w, rot = 0, color = '#FFFDF4', pin = true, children}) => {
  const t = useT();
  const pop = usePop(t0, 12, 150);
  if (t < t0 || t > t1) return null;
  const out = clamp((t1 - t) / 0.25, 0, 1);
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: w,
        boxSizing: 'border-box',
        background: color,
        border: `5px solid ${INK}`,
        borderRadius: 26,
        padding: '26px 34px',
        boxShadow: '0 12px 0 rgba(0,0,0,0.16)',
        fontFamily,
        color: INK,
        opacity: out,
        transform: `rotate(${rot}deg) scale(${pop})`,
        transformOrigin: '50% 0%',
      }}
    >
      {pin && (
        <div
          style={{
            position: 'absolute',
            left: '50%',
            top: -20,
            width: 34,
            height: 34,
            marginLeft: -17,
            borderRadius: 999,
            background: '#E8574A',
            border: `4px solid ${INK}`,
          }}
        />
      )}
      {children}
    </div>
  );
};

// বোল্ড স্ট্যাম্প ব্যাজ (ধপ করে পড়ে)
export const Stamp: React.FC<{
  t0: number;
  t1: number;
  x: number;
  y: number;
  text: string;
  color?: string;
  rot?: number;
  size?: number;
}> = ({t0, t1, x, y, text, color = '#E0453A', rot = -6, size = 64}) => {
  const t = useT();
  const pop = usePop(t0, 9, 220);
  if (t < t0 || t > t1) return null;
  const out = clamp((t1 - t) / 0.25, 0, 1);
  const sc = 1 + (1 - pop) * 1.4;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${sc})`,
        opacity: clamp(pop * 1.4, 0, 1) * out,
        fontFamily,
        fontWeight: 700,
        fontSize: size,
        color,
        border: `8px solid ${color}`,
        borderRadius: 22,
        padding: '4px 34px 10px',
        background: 'rgba(255,255,255,0.85)',
        whiteSpace: 'nowrap',
        letterSpacing: 1,
      }}
    >
      {text}
    </div>
  );
};

// ক্যামেরা: জুম + হালকা ঝাঁকুনি (শুধু স্টেজ SVG-তে)
export const Cam: React.FC<{zoom?: number; cx?: number; cy?: number; shake?: number; children: React.ReactNode}> = ({
  zoom = 1,
  cx = 960,
  cy = 540,
  shake = 0,
  children,
}) => {
  const f = useCurrentFrame();
  const sx = Math.sin(f * 1.9) * shake;
  const sy = Math.cos(f * 2.7) * shake;
  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        transform: `translate(${sx}px,${sy}px) scale(${zoom})`,
        transformOrigin: `${cx}px ${cy}px`,
      }}
    >
      {children}
    </div>
  );
};

// সিনের শুরু/শেষে ক্রিম ডিপ-ফেড
export const SceneFrame: React.FC<{dur: number; bg?: string; children: React.ReactNode}> = ({dur, bg = CREAM, children}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const a = clamp(f / 7, 0, 1) * clamp((dur - f) / 6, 0, 1);
  void fps;
  return (
    <AbsoluteFill style={{background: bg, overflow: 'hidden'}}>
      <AbsoluteFill style={{opacity: a}}>{children}</AbsoluteFill>
    </AbsoluteFill>
  );
};

// SVG স্টেজ: ১৯২০x১০৮০ কোঅর্ডিনেটে আঁকা, ১০০% ফুল-স্ক্রিন
export const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg
    viewBox="0 0 1920 1080"
    width={1920}
    height={1080}
    preserveAspectRatio="none"
    style={{position: 'absolute', left: 0, top: 0, width: '100%', height: '100%'}}
  >
    {children}
  </svg>
);

export {fadeWin};
