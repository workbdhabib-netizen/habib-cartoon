import {loadFont} from '@remotion/google-fonts/HindSiliguri';

export const {fontFamily} = loadFont('normal', {
  weights: ['400', '600', '700'],
  subsets: ['bengali', 'latin'],
});

export const INK = '#222222';
export const SW = 2.5; // outline stroke width
export const HL = '#FFD84A'; // caption highlight
export const CREAM = '#FBE9C6';
