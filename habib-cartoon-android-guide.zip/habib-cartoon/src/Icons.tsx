import React from 'react';
import {INK, fontFamily} from './theme';
import {fadeWin, useT, usePop} from './lib';

const S = {stroke: INK, strokeWidth: 4, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

export type IconName =
  | 'drop' | 'mug' | 'coin' | 'calendar' | 'clock' | 'sun' | 'question' | 'bulb'
  | 'heart' | 'warning' | 'phone' | 'spoon' | 'check' | 'lau' | 'leaf' | 'sparkle' | 'ribbon' | 'star';

const SHAPES: Record<IconName, React.ReactNode> = {
  drop: (
    <>
      <path d="M50 8 C50 8 18 46 18 66 A32 32 0 0 0 82 66 C82 46 50 8 50 8Z" fill="#4FB4F2" {...S} />
      <path d="M33 66 A17 17 0 0 0 48 83" stroke="#fff" strokeWidth={5} fill="none" strokeLinecap="round" />
    </>
  ),
  mug: (
    <>
      <path d="M72 38 H84 A12 12 0 0 1 84 66 H70" fill="none" {...S} />
      <path d="M18 28 H74 V74 A12 12 0 0 1 62 86 H30 A12 12 0 0 1 18 74 Z" fill="#4A86E8" {...S} />
      <rect x="18" y="28" width="56" height="10" fill="#fff" {...S} />
      <path d="M34 52 V68" stroke="#fff" strokeWidth={5} strokeLinecap="round" />
    </>
  ),
  coin: (
    <>
      <rect x="6" y="24" width="88" height="52" rx="8" fill="#7BC47F" {...S} />
      <circle cx="50" cy="50" r="17" fill="#CFEFC9" {...S} />
      <text x="50" y="59" textAnchor="middle" fontSize="26" fontWeight="700" fontFamily={fontFamily} fill={INK}>৳</text>
      <text x="17" y="42" textAnchor="middle" fontSize="15" fontWeight="700" fontFamily={fontFamily} fill={INK}>২০</text>
      <text x="83" y="68" textAnchor="middle" fontSize="15" fontWeight="700" fontFamily={fontFamily} fill={INK}>২০</text>
    </>
  ),
  calendar: (
    <>
      <rect x="14" y="20" width="72" height="68" rx="8" fill="#fff" {...S} />
      <path d="M14 28 a8 8 0 0 1 8 -8 H78 a8 8 0 0 1 8 8 V42 H14Z" fill="#E8574A" {...S} />
      <path d="M32 12 V28 M68 12 V28" {...S} />
      <path d="M30 60 l9 9 l18 -20" fill="none" stroke="#2E9E5B" strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" />
    </>
  ),
  clock: (
    <>
      <circle cx="50" cy="50" r="38" fill="#fff" {...S} />
      <path d="M50 24 V50 L68 60" fill="none" {...S} />
      <circle cx="50" cy="50" r="4" fill={INK} />
    </>
  ),
  sun: (
    <>
      {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => (
        <path key={a} d="M50 6 V20" transform={`rotate(${a} 50 50)`} {...S} stroke="#F2A81D" />
      ))}
      <circle cx="50" cy="50" r="22" fill="#FFD23F" {...S} />
    </>
  ),
  question: (
    <>
      <circle cx="50" cy="50" r="40" fill="#8E6FD8" {...S} />
      <text x="50" y="68" textAnchor="middle" fontSize="58" fontWeight="700" fontFamily={fontFamily} fill="#fff">?</text>
    </>
  ),
  bulb: (
    <>
      <path d="M50 8 A28 28 0 0 1 66 58 V68 H34 V58 A28 28 0 0 1 50 8Z" fill="#FFE066" {...S} />
      <rect x="36" y="68" width="28" height="12" rx="4" fill="#bbb" {...S} />
      <path d="M42 88 H58" {...S} />
    </>
  ),
  heart: (
    <path d="M50 86 C14 58 8 36 24 22 C36 12 48 20 50 30 C52 20 64 12 76 22 C92 36 86 58 50 86Z" fill="#F0577A" {...S} />
  ),
  warning: (
    <>
      <path d="M50 10 L92 84 H8 Z" fill="#FFC93C" {...S} />
      <path d="M50 38 V62" stroke={INK} strokeWidth={7} strokeLinecap="round" />
      <circle cx="50" cy="73" r="4.5" fill={INK} />
    </>
  ),
  phone: (
    <>
      <rect x="26" y="6" width="48" height="88" rx="9" fill="#2B2F36" {...S} />
      <rect x="31" y="16" width="38" height="62" rx="3" fill="#D9F2D0" />
      <path d="M50 70 V50" stroke="#3E8E41" strokeWidth={4} strokeLinecap="round" />
      <path d="M50 52 Q38 50 36 38 Q48 38 50 52Z M50 56 Q62 52 64 42 Q52 42 50 56Z" fill="#6BBF59" />
      <circle cx="50" cy="86" r="3" fill="#888" />
    </>
  ),
  spoon: (
    <>
      <path d="M50 44 V92" {...S} strokeWidth={8} stroke="#9AA3AD" />
      <ellipse cx="50" cy="28" rx="16" ry="22" fill="#C9D0D8" {...S} />
    </>
  ),
  check: (
    <>
      <circle cx="50" cy="50" r="40" fill="#35B36B" {...S} />
      <path d="M30 52 l14 14 l27 -30" fill="none" stroke="#fff" strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" />
    </>
  ),
  lau: (
    <>
      <path d="M44 6 Q50 2 56 8 L56 20 Q80 30 80 58 Q80 90 50 92 Q20 90 20 58 Q20 30 44 20Z" fill="#9FD48B" {...S} />
      <path d="M36 54 Q38 74 48 82" stroke="#fff" strokeWidth={5} fill="none" strokeLinecap="round" opacity=".7" />
    </>
  ),
  leaf: (
    <>
      <path d="M14 82 Q10 24 78 14 Q88 80 14 82Z" fill="#59B85A" {...S} />
      <path d="M14 82 Q40 52 70 26" fill="none" {...S} strokeWidth={3} />
    </>
  ),
  sparkle: (
    <path d="M50 4 Q54 44 96 50 Q54 56 50 96 Q46 56 4 50 Q46 44 50 4Z" fill="#FFE066" {...S} strokeWidth={3} />
  ),
  ribbon: (
    <>
      <path d="M50 46 L14 24 Q8 50 14 74 Z" fill="#E8332F" {...S} />
      <path d="M50 46 L86 24 Q92 50 86 74 Z" fill="#E8332F" {...S} />
      <circle cx="50" cy="48" r="9" fill="#C0201C" {...S} />
      <path d="M46 56 L36 92 M54 56 L64 92" {...S} stroke="#E8332F" strokeWidth={9} />
    </>
  ),
  star: (
    <path d="M50 8 L61 38 L93 40 L68 60 L77 92 L50 74 L23 92 L32 60 L7 40 L39 38Z" fill="#FFD23F" {...S} />
  ),
};

interface IconProps {
  name: IconName;
  x: number; // কেন্দ্র
  y: number;
  size?: number;
  t0: number;
  t1: number;
  float?: number; // ওঠানামা
  pulse?: boolean;
  spin?: number; // ডিগ্রি/সেকেন্ড
  rot?: number;
}

// পপ-আপ করে ভাসা অ্যানিমেটেড আইকন (HTML overlay)
export const Icon: React.FC<IconProps> = ({name, x, y, size = 110, t0, t1, float = 8, pulse = false, spin = 0, rot = 0}) => {
  const t = useT();
  const pop = usePop(t0);
  if (t < t0 || t > t1) return null;
  const out = fadeWin(t, t0, t1, 0.01, 0.25);
  const fy = Math.sin((t - t0) * 3) * float;
  const ps = pulse ? 1 + Math.sin((t - t0) * 7) * 0.07 : 1;
  return (
    <div
      style={{
        position: 'absolute',
        left: x - size / 2,
        top: y - size / 2 + fy,
        width: size,
        height: size,
        opacity: out,
        transform: `scale(${pop * ps}) rotate(${rot + spin * (t - t0)}deg)`,
        filter: 'drop-shadow(0 6px 0 rgba(0,0,0,0.12))',
      }}
    >
      <svg viewBox="0 0 100 100" width={size} height={size}>
        {SHAPES[name]}
      </svg>
    </div>
  );
};

// ছোট ইনলাইন SVG আইকন (অন্য কম্পোনেন্টের ভেতরে ব্যবহারের জন্য)
export const IconSvg: React.FC<{name: IconName; size: number}> = ({name, size}) => (
  <svg viewBox="0 0 100 100" width={size} height={size} style={{display: 'block'}}>
    {SHAPES[name]}
  </svg>
);
