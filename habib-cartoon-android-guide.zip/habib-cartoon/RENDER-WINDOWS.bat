@echo off
title Habib Cartoon MP4 Renderer
echo Installing project dependencies (first run only)...
call npm install
if errorlevel 1 goto error
echo Rendering MP4 video...
call npx remotion render MainVideo out\video.mp4
if errorlevel 1 goto error
echo.
echo Finished! Your MP4 is in the out folder: video.mp4
pause
exit /b 0
:error
echo Something went wrong. Check that Node.js is installed and internet is available.
pause
exit /b 1
