#!/usr/bin/env bash
set -e
npm install
npx remotion render MainVideo out/video.mp4
