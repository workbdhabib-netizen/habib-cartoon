# হাবিব ও লাউয়ের চারা — MP4 Render Guide

## Android ফোন
Android ফোনে সরাসরি Remotion রেন্ডার করা নির্ভরযোগ্য নয়। ফোন থেকে রেন্ডার করতে browser-based Linux workspace ব্যবহার করার নির্দেশনা `ANDROID-RENDER.md` ফাইলে আছে।

## Windows
1. Node.js LTS ইনস্টল করো।
2. ZIP Extract করো।
3. `RENDER-WINDOWS.bat` ডাবল-ক্লিক করো।
4. রেন্ডার শেষে `out/video.mp4` পাওয়া যাবে।

## macOS / Linux
```bash
chmod +x render-mac-linux.sh
./render-mac-linux.sh
```

## Preview
```bash
npm install
npx remotion studio
```
